-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2017 at 06:53 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jemarental`
--

-- --------------------------------------------------------

--
-- Table structure for table `leases`
--

CREATE TABLE `leases` (
  `id` int(10) UNSIGNED NOT NULL,
  `terms_and_agreements` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `agreed_monthly_rent` decimal(7,2) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lease_preferences`
--

CREATE TABLE `lease_preferences` (
  `id` int(10) UNSIGNED NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apprximate_cost` decimal(7,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_10_17_081428_create_properties_table', 1),
(4, '2017_10_17_110110_create_tenants_table', 1),
(5, '2017_10_23_071336_create_transactions_table', 1),
(6, '2017_11_03_093338_create_units_table', 1),
(7, '2017_11_07_073429_create_property_tenants_table', 1),
(16, '2017_11_22_161821_create_leases_table', 2),
(17, '2017_11_22_161849_create_lease_preferences_table', 2),
(19, '2017_11_22_160308_create_property_for_rents_table', 3),
(22, '2017_11_22_161247_create_property_units_table', 4),
(24, '2017_11_22_161807_create_new_model_tenants_table', 5),
(27, '2017_11_22_161558_create_unit_monthly_transactions_table', 6),
(28, '2017_11_22_161500_create_property_monthly_transactions_table', 7),
(29, '2017_11_22_161537_create_unit_expenses_table', 8),
(32, '2017_11_22_161433_create_property_general_expenses_table', 9);

-- --------------------------------------------------------

--
-- Table structure for table `new_model_tenants`
--

CREATE TABLE `new_model_tenants` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `sex` char(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `new_model_tenants`
--

INSERT INTO `new_model_tenants` (`id`, `first_name`, `middle_name`, `last_name`, `date_of_birth`, `sex`, `email`, `phone`, `created_at`, `updated_at`) VALUES
(4, 'Israel', 'Ngoda', 'Kaubana', '2017-12-15', 'M', 'isy.ngoda@gmail.com', '0786786778', '2017-12-01 14:47:52', '2017-12-01 14:47:52'),
(5, 'Najim', 'Saleh', 'Kassim', '2017-12-15', 'M', 'najimsaleh123@gmail.com', '0786786778', '2017-12-01 14:48:21', '2017-12-01 14:48:21'),
(6, 'Elon', 'Musk', 'Najim', '2017-12-23', 'M', 'najimsaleh123@gmail.com', '0786786778', '2017-12-01 14:48:48', '2017-12-01 14:48:48'),
(8, 'Tarimo', 'Evans', 'Evans', '2017-12-29', 'M', 'tarimo@gmail.com', '0786786778', '2017-12-01 14:49:24', '2017-12-01 14:49:24');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(10) UNSIGNED NOT NULL,
  `propName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plotNo` int(11) NOT NULL,
  `blockNo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `propType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `propName`, `plotNo`, `blockNo`, `street`, `region`, `propType`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Seedfarm', 17, '7', 'Songea', 'Ruvuma', 'Single-Unit', 0, '2017-11-13 07:50:29', '2017-11-13 07:50:29'),
(2, 'Jema', 11, '13', 'Songea', 'Ruvuma', 'Multi-Unit', 0, '2017-11-13 08:12:17', '2017-11-13 08:12:17'),
(3, 'new property 1', 1, '2', 'Street A', 'Region A', 'Single-Unit', 0, '2017-11-30 08:54:17', '2017-11-30 08:54:17');

-- --------------------------------------------------------

--
-- Table structure for table `property_for_rents`
--

CREATE TABLE `property_for_rents` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_first_usage` date DEFAULT NULL,
  `fixed_monthly_rent` decimal(7,2) DEFAULT NULL,
  `occupied` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plot_no` int(11) NOT NULL,
  `block_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lease_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_for_rents`
--

INSERT INTO `property_for_rents` (`id`, `property_name`, `profile`, `property_type`, `date_of_first_usage`, `fixed_monthly_rent`, `occupied`, `plot_no`, `block_no`, `street`, `region`, `lease_id`, `created_at`, `updated_at`) VALUES
(9, 'Madale', 'Gorgeous-Interior-Looks-House.jpg', 'Multi-Unit', NULL, '5000.00', NULL, 1, '1', 'Street A', 'Region A', NULL, '2017-12-01 14:30:18', '2017-12-01 14:42:00'),
(10, 'Savei', 'Gorgeous-Interior-Looks-House.jpg', 'Multi-Unit', NULL, NULL, NULL, 2, '2', 'Street B', 'Region B', NULL, '2017-12-01 14:43:32', '2017-12-01 14:43:32'),
(11, 'Bunju', 'Gorgeous-Interior-Looks-House.jpg', 'Single-Unit', NULL, NULL, NULL, 3, '3', 'Street C', 'Region C', NULL, '2017-12-01 14:44:31', '2017-12-01 14:44:31');

-- --------------------------------------------------------

--
-- Table structure for table `property_general_expenses`
--

CREATE TABLE `property_general_expenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `date_incurred` date NOT NULL,
  `amount_involved` decimal(7,2) NOT NULL,
  `property` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_general_expenses`
--

INSERT INTO `property_general_expenses` (`id`, `date_incurred`, `amount_involved`, `property`, `category`, `transaction_type`, `tenant`, `created_at`, `updated_at`) VALUES
(1, '2017-12-22', '500.00', 'new property 3', 'Plumbing', 'cash', 'Bibi Bibi', '2017-12-01 01:08:45', '2017-12-01 01:08:45');

-- --------------------------------------------------------

--
-- Table structure for table `property_monthly_transactions`
--

CREATE TABLE `property_monthly_transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `property` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_transaction` date NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `amount_received` decimal(7,2) NOT NULL,
  `newModelTenant` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_monthly_transactions`
--

INSERT INTO `property_monthly_transactions` (`id`, `property`, `transaction_type`, `date_of_transaction`, `category`, `from`, `to`, `amount_received`, `newModelTenant`, `created_at`, `updated_at`) VALUES
(1, 'new property 1', 'cash', '2017-12-07', 'Rent', '2017-12-08', '2018-01-08', '400.00', 'Bibi Bibi', '2017-11-30 21:41:11', '2017-11-30 21:41:11');

-- --------------------------------------------------------

--
-- Table structure for table `property_tenant`
--

CREATE TABLE `property_tenant` (
  `id` int(10) UNSIGNED NOT NULL,
  `propertyId` int(11) NOT NULL,
  `tenantId` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_tenant`
--

INSERT INTO `property_tenant` (`id`, `propertyId`, `tenantId`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2017-11-14 09:05:39', '2017-11-14 09:05:39'),
(2, 1, 1, '2017-11-14 09:05:42', '2017-11-14 09:05:42'),
(3, 1, 1, '2017-11-14 09:05:46', '2017-11-14 09:05:46');

-- --------------------------------------------------------

--
-- Table structure for table `property_units`
--

CREATE TABLE `property_units` (
  `id` int(10) UNSIGNED NOT NULL,
  `unit_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_no` int(11) NOT NULL,
  `fixed_monthly_rent` decimal(7,2) NOT NULL,
  `property_id` int(11) NOT NULL,
  `occupied` char(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `property_units`
--

INSERT INTO `property_units` (`id`, `unit_type`, `unit_no`, `fixed_monthly_rent`, `property_id`, `occupied`, `created_at`, `updated_at`) VALUES
(1, 'room', 1, '500.00', 8, NULL, '2017-11-30 10:52:35', '2017-11-30 10:52:35'),
(2, 'room', 1, '100.00', 9, NULL, '2017-12-01 14:30:18', '2017-12-01 14:30:18'),
(3, 'room', 3, '100.00', 9, NULL, '2017-12-01 14:30:18', '2017-12-01 14:30:18'),
(4, 'master_room', 2, '300.00', 9, NULL, '2017-12-01 14:30:18', '2017-12-01 14:30:18'),
(5, 'master_room', 1, '400.00', 10, NULL, '2017-12-01 14:43:32', '2017-12-01 14:43:32'),
(6, 'room', 4, '100.00', 10, NULL, '2017-12-01 14:43:32', '2017-12-01 14:43:32'),
(7, 'room', 3, '100.00', 10, NULL, '2017-12-01 14:43:32', '2017-12-01 14:43:32'),
(8, 'room', 2, '100.00', 10, NULL, '2017-12-01 14:43:32', '2017-12-01 14:43:32'),
(9, 'master_room', 1, '500.00', 11, NULL, '2017-12-01 14:44:31', '2017-12-01 14:44:31');

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `id` int(10) UNSIGNED NOT NULL,
  `fname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tenants`
--

INSERT INTO `tenants` (`id`, `fname`, `sname`, `lname`, `companyName`, `dob`, `email`, `gender`, `mobile`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Najim', 'Kassim', 'Saleh', 'OCL', '1993-11-19', 'najim@gmail.com', 'Male', '0686000111', 0, '2017-11-14 09:01:36', '2017-11-14 09:01:36'),
(2, 'Evans', 'Anselm', 'Tarimo', 'OCL', '1994-02-08', 'evans@gmail.com', 'Male', '0686000111', 0, '2017-11-14 09:02:49', '2017-11-14 09:02:49'),
(3, 'Julieth', 'Anselm', 'Majaliwa', 'FNL', '1998-03-01', 'juelth@gmail.com', 'Female', '0686000111', 0, '2017-11-14 09:03:38', '2017-11-14 09:03:38');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `tenantId` int(11) NOT NULL,
  `propertyId` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  `payDate` date DEFAULT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int(11) NOT NULL,
  `transType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lease` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startDate` date DEFAULT NULL,
  `endDate` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(10) UNSIGNED NOT NULL,
  `propertyId` int(11) NOT NULL,
  `unit_no` int(11) NOT NULL,
  `unit_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit_rent` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `propertyId`, `unit_no`, `unit_type`, `unit_rent`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'room', 12000, '2017-11-13 07:50:30', '2017-11-13 07:50:30'),
(2, 1, 2, 'master_room', 20000, '2017-11-13 07:50:30', '2017-11-13 07:50:30'),
(3, 2, 1, 'commercial', 7000, '2017-11-13 08:12:18', '2017-11-13 08:12:18'),
(4, 2, 2, 'storage', 5000, '2017-11-13 08:12:18', '2017-11-13 08:12:18');

-- --------------------------------------------------------

--
-- Table structure for table `unit_expenses`
--

CREATE TABLE `unit_expenses` (
  `id` int(10) UNSIGNED NOT NULL,
  `date_incurred` date NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount_involved` decimal(7,2) NOT NULL,
  `property` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `unit_expenses`
--

INSERT INTO `unit_expenses` (`id`, `date_incurred`, `unit`, `amount_involved`, `property`, `category`, `transaction_type`, `tenant`, `created_at`, `updated_at`) VALUES
(1, '2017-12-15', 'room', '500.00', 'new property 1', 'Electricity', 'cash', 'Bibi Bibi', '2017-12-01 00:32:24', '2017-12-01 00:32:24');

-- --------------------------------------------------------

--
-- Table structure for table `unit_monthly_transactions`
--

CREATE TABLE `unit_monthly_transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `property` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_transaction` date NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` date NOT NULL,
  `to` date NOT NULL,
  `amount_received` decimal(7,2) NOT NULL,
  `newModelTenant` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `unit_monthly_transactions`
--

INSERT INTO `unit_monthly_transactions` (`id`, `unit`, `property`, `transaction_type`, `date_of_transaction`, `category`, `from`, `to`, `amount_received`, `newModelTenant`, `created_at`, `updated_at`) VALUES
(8, 'room', 'new property 3', 'prepaid', '2017-12-12', 'Rent', '2017-12-14', '2018-01-14', '200.00', 'Bibi Bibi', '2017-11-30 18:28:46', '2017-11-30 18:28:46'),
(9, 'room', 'new property 3', 'prepaid', '2017-12-12', 'Rent', '2017-12-14', '2018-01-14', '200.00', 'Bibi Bibi', '2017-11-30 18:37:06', '2017-11-30 18:37:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Israel Ngoda', 'isy.ngoda@gmail.com', '$2y$10$nSTc1P/io9f9jtmSA1tmTuLsph2PBIWFAuOcFZbHm54kOHmA.qhnO', NULL, '2017-11-13 06:31:39', '2017-11-13 06:31:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `leases`
--
ALTER TABLE `leases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lease_preferences`
--
ALTER TABLE `lease_preferences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `new_model_tenants`
--
ALTER TABLE `new_model_tenants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_for_rents`
--
ALTER TABLE `property_for_rents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_general_expenses`
--
ALTER TABLE `property_general_expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_monthly_transactions`
--
ALTER TABLE `property_monthly_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_tenant`
--
ALTER TABLE `property_tenant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property_units`
--
ALTER TABLE `property_units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tenants_email_unique` (`email`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit_expenses`
--
ALTER TABLE `unit_expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit_monthly_transactions`
--
ALTER TABLE `unit_monthly_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `leases`
--
ALTER TABLE `leases`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lease_preferences`
--
ALTER TABLE `lease_preferences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `new_model_tenants`
--
ALTER TABLE `new_model_tenants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `property_for_rents`
--
ALTER TABLE `property_for_rents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `property_general_expenses`
--
ALTER TABLE `property_general_expenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `property_monthly_transactions`
--
ALTER TABLE `property_monthly_transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `property_tenant`
--
ALTER TABLE `property_tenant`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `property_units`
--
ALTER TABLE `property_units`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tenants`
--
ALTER TABLE `tenants`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `unit_expenses`
--
ALTER TABLE `unit_expenses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `unit_monthly_transactions`
--
ALTER TABLE `unit_monthly_transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
