<?php $__env->startSection('content'); ?>

  <div class="content">
                   <div class="container-fluid">
                       <div class="row">
                           <div class="col-md-12">
                               <div class="card">
                                   <div class="header">
                                       <div class="col-md-10">
                                           <div class="row">
                                               <h4 class="title">Tenants</h4>
                                               <p class="category">Sub heading goes here</p>
                                           </div>
                                       </div>
                                       <div class="col-md-2">
                                           <a class="btn btn-primary" href="<?php echo e(route('tenant.create')); ?>">+ Add new tenant</a>
                                       </div>
                                   </div>
                                   <div class="content">
                                       <div class="row">
                                           <div class="content table-responsive table-full-width">
                                               <table class="table table-hover table-striped">
                                                   <thead>
                                                       <th>Sn</th>
                                                       <th>Tenant Name</th>
                                                       <th>Property Name</th>
                                                       <th>Unit #</th>
                                                       <th>Phone</th>
                                                       <th>Lease / Duration</th>
                                                       <th>Action</th>
                                                   </thead>
                                                   <tbody>
                                                     <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <tr>
                                                           <td><?php echo e($tenant -> id); ?></td>
                                                           <td><?php echo e($tenant -> fname); ?> <?php echo e($tenant -> lname); ?></td>
                                                           <td>Seedfarm</td>
                                                           <td>1</td>
                                                           <td><?php echo e($tenant -> mobile); ?></td>
                                                           <td>3 months</td>
                                                           <td>
                                                               <a href="<?php echo e(route('tenant.show', $tenant -> id)); ?>"><span class="label label-success">View</span></a>
                                                               <a href="edit.html"><span class="label label-primary">Edit</span></a>
                                                               <a href=""><span class="label label-danger">Delete</span></a>
                                                           </td>
                                                       </tr>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   </tbody>
                                               </table>
                                           </div>
                                       </div>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>