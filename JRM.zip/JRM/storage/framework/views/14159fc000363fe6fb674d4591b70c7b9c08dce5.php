<?php $__env->startSection('breadcrumb'); ?>

  Monthly Property Report

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content">
      <div class="container-fluid">
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="content">
                          <form>
                              <div class="row">
                                  <div class="col-md-10">
                                      <div class="form-group">
                                          <label>Sort by Property</label>
                                          <select class="form-control">
                                              <option>all properties</option>
                                              <option>Seedfarm</option>
                                              <option>Msamala</option>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-2">
                                      <div class="form-group">
                                          <label>Download PDF & Excel</label>
                                          <input type="submit" class="btn btn-success pull-right" value="Download">
                                      </div>
                                  </div>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="content">
                          <div class="row">
                              <div class="col-md-9">
                                  <div class="" style="padding: 20px 10px;">
                                      <h3>MONTHLY PROPERTY REPORT</h3>
                                  </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="">
                                      <p style="text-align: right; padding: 20px 10px;">
                                          Jema <br>
                                          255789828005 <br>
                                          evansanselm@gmail.com <br>
                                          01/01/2017 - 13/10/2017
                                      </p>
                                  </div>
                              </div>
                          </div>
                          <div class="row">
                              <div class="col-md-12">
                                  <div class="content table-responsive table-full-width">
                                      <table class="table">
                                          <thead>
                                              <tr>
                                                  <td colspan="6">
                                                      <p>
                                                          <small>PROPERTY</small><br>
                                                          SEEDFARM<br>
                                                          <small>seedfarm, Songea, Ruvuma Region, 105716, TZ</small>
                                                      </p>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <th>Unit</th>
                                                  <th>Tenant</th>
                                                  <th>Lease</th>
                                                  <th>Lease Start</th>
                                                  <th>Lease End</th>
                                                  <th>Balance Owed</th>
                                              </tr>

                                          </thead>
                                          <tbody>
                                              <tr>
                                                  <td>1</td>
                                                  <td>Israel Ngoda</td>
                                                  <td>3</td>
                                                  <td>13/10/2017</td>
                                                  <td>13/12/2017</td>
                                                  <td>Tsh 0</td>
                                              </tr>
                                              <tr>
                                                  <td>2</td>
                                                  <td>Evans chis</td>
                                                  <td>6</td>
                                                  <td>13/10/2017</td>
                                                  <td>13/03/2018</td>
                                                  <td>Tsh 0</td>
                                              </tr>
                                              <tr>
                                                  <td>3</td>
                                                  <td>Vacant</td>
                                                  <td>-</td>
                                                  <td>-</td>
                                                  <td>-</td>
                                                  <td>-</td>
                                              </tr>
                                          </tbody>
                                      </table>
                                  </div>
                                  <div class="content table-responsive table-full-width">
                                      <table class="table">
                                          <thead>
                                              <tr>
                                                  <td colspan="6">
                                                      <p>
                                                          <small>PROPERTY</small><br>
                                                          MSAMALA<br>
                                                          <small>Msamala, Ruvuma, Ruvuma, 705, TZ</small>
                                                      </p>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <th>Unit</th>
                                                  <th>Tenant</th>
                                                  <th>Lease</th>
                                                  <th>Lease Start</th>
                                                  <th>Lease End</th>
                                                  <th>Balance Owed</th>
                                              </tr>

                                          </thead>
                                          <tbody>
                                              <tr>
                                                  <td>1</td>
                                                  <td>Israel Ngoda</td>
                                                  <td>3</td>
                                                  <td>13/10/2017</td>
                                                  <td>13/12/2017</td>
                                                  <td>Tsh 0</td>
                                              </tr>
                                              <tr>
                                                  <td>2</td>
                                                  <td>Evans chis</td>
                                                  <td>6</td>
                                                  <td>13/10/2017</td>
                                                  <td>13/03/2018</td>
                                                  <td>Tsh 0</td>
                                              </tr>
                                              <tr>
                                                  <td>3</td>
                                                  <td>Vacant</td>
                                                  <td>-</td>
                                                  <td>-</td>
                                                  <td>-</td>
                                                  <td>-</td>
                                              </tr>
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>