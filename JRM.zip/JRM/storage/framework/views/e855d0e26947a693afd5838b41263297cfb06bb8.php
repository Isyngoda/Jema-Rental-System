

<?php $__env->startSection('content'); ?>

  <div class="content">
    <div class="container-fluid">
      <div class="row">
              <div class="col-md-6">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Quick Buttons</h4>
                          <p class="category">Sub heading goes here</p>
                      </div>
                      <div class="content all-icons">
                          <div class="row">
                              <!-- add new property -->
                              <a class="quick-links" href="<?php echo e(route('properties.create')); ?>">
                                <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <i class="pe-7s-home"></i>
                                      <p>ADD NEW PROPERTY</p>
                                  </div>
                                </div>
                              </a>
                              <!-- / -->
                              <!-- add new expense -->
                              <a class="quick-links" href="<?php echo e(route('expenses.create')); ?>">
                                <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <i class="pe-7s-cash"></i>
                                      <p>ADD NEW EXPENSE</p>
                                  </div>
                                </div>
                              </a>
                              <!-- / -->
                              <!-- add new tenant -->
                              <a class="quick-links" href="<?php echo e(route('tenants.create')); ?>">
                                <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <i class="pe-7s-user"></i>
                                      <p>ADD NEW TENANT</p>
                                  </div>
                                </div>
                              </a>
                              <!-- / -->
                              <!-- add new income -->
                              <a class="quick-links" href="<?php echo e(route('incomes.create')); ?>">
                                <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <i class="pe-7s-cash"></i>
                                      <p>ADD NEW INCOME</p>
                                  </div>
                                </div>
                              </a>
                            <!-- / -->
                          </div>
                      </div>
                  </div>
              </div>
      </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>