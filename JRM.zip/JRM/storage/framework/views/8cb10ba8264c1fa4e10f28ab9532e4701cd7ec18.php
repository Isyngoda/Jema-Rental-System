<?php $__env->startSection('breadcrumb'); ?>

  Expense Report

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content">
      <div class="container-fluid">
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="content">
                          <form>
                              <div class="row">
                                  <div class="col-md-6">
                                      <div class="form-group">
                                          <label>Sort by Property</label>
                                          <select class="form-control">
                                              <option>all properties</option>
                                              <option>Seedfarm</option>
                                              <option>Msamala</option>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-3">
                                      <div class="form-group">
                                          <label>Sort by Account</label>
                                          <select class="form-control">
                                              <option>all properties</option>
                                              <option>Painting</option>
                                              <option>Plumbing</option>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-3">
                                      <div class="form-group">
                                          <label>Sort by Unit</label>
                                          <select class="form-control">
                                              <option>all units</option>
                                              <option>#1</option>
                                              <option>#2</option>
                                          </select>
                                      </div>
                                  </div>
                              </div>
                              <div class="row">
                                  <div class="col-md-9">
                                      <div class="form-group">
                                          <input class="form-control" placeholder="Date Range" type="date" name="" value="">
                                      </div>
                                  </div>
                                  <div class="col-md-3">
                                      <div class="form-group">
                                          <input type="submit" class="btn btn-success" value="Filter">
                                      </div>
                                  </div>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="content">
                          <div class="row">
                              <div class="col-md-9">
                                  <div class="" style="padding: 20px 10px;">
                                      <h3>EXPENSE REPORT</h3>
                                  </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="">
                                      <p style="text-align: right; padding: 20px 10px;">
                                          Jema <br>
                                          255789828005 <br>
                                          evansanselm@gmail.com <br>
                                          01/01/2017 - 13/10/2017 <br>
                                      </p>
                                  </div>
                              </div>
                          </div>
                          <div class="row">
                              <div class="col-md-12">
                                  <div class="content table-responsive table-full-width">
                                      <table class="table">
                                          <thead>
                                              <tr>
                                                  <td colspan="4">
                                                      <p><small>PROPERTY</small></p>
                                                      <p>SEEDFARM</p>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <th>Unit</th>
                                                  <th>Account</th>
                                                  <th>Amount</th>
                                                  <th>Type</th>
                                              </tr>

                                          </thead>
                                          <tbody>
                                              <tr>
                                                  <td rowspan="3"><b>1</b></td>
                                                  <td>Electrical Maintnance</td>
                                                  <td>Tsh 50,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td>Plumbing</td>
                                                  <td>Tsh 30,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td><b>Total</b></td>
                                                  <td colspan="2"><b>Tsh 80,000</b></td>
                                              </tr>
                                          </tbody>
                                          <tbody>
                                              <tr>
                                                  <td colspan="2"></td>
                                                  <td align="right" colspan="2" style="background: #333; color: #fff;">
                                                      <div>
                                                          <small>Total</small>
                                                          <p>Tsh 80,000</p>
                                                      </div>
                                                  </td>
                                              </tr>
                                          </tbody>
                                      </table>
                                  </div>
                                  <div class="content table-responsive table-full-width">
                                      <table class="table">
                                          <thead>
                                              <tr>
                                                  <td colspan="4">
                                                      <p><small>PROPERTY</small></p>
                                                      <p>MSAMALA</p>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <th>Unit</th>
                                                  <th>Account</th>
                                                  <th>Amount</th>
                                                  <th>Type</th>
                                              </tr>

                                          </thead>
                                          <tbody>
                                              <!-- first unit -->
                                              <tr>
                                                  <td rowspan="3"><b>1</b></td>
                                                  <td>Electrical Maintnance</td>
                                                  <td>Tsh 50,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td>Plumbing</td>
                                                  <td>Tsh 30,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td><b>Total</b></td>
                                                  <td colspan="2"><b>Tsh 80,000</b></td>
                                              </tr>
                                              <!-- second unit -->
                                              <tr>
                                                  <td rowspan="3"><b>2</b></td>
                                                  <td>Painting</td>
                                                  <td>Tsh 20,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td>Plumbing</td>
                                                  <td>Tsh 30,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td><b>Total</b></td>
                                                  <td colspan="2"><b>Tsh 50,000</b></td>
                                              </tr>
                                          </tbody>
                                          <tbody>
                                              <tr>
                                                  <td colspan="2"></td>
                                                  <td align="right" colspan="2" style="background: #333; color: #fff;">
                                                      <div>
                                                          <small>Total</small>
                                                          <p>Tsh 130,000</p>
                                                      </div>
                                                  </td>
                                              </tr>
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>