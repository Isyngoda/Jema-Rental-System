<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use propertyForRent; // import the required model class

use unitMonthlyTransaction; // import the required model class

use unitExpense; // import the required model class

use lease; // import the required model class

class propertyUnit extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined

    /*
    *
    * Establish the reverse relationship between property_unit and proprty_for_rent
    *
    */

    public function propertyForRent ()
    {
        return $this->belongsTo('App\propertyForRent'); // a property_unit belongs to a property_for_rent
    }

    /*
    *
    * Establish the relationship between property_unit and unit_monthly_transaction
    *
    */

    public function unitMonthlyTransaction()
    {
        return $this->hasOne('App\unitMonthlyTransaction'); // a unit has 1 monthly transaction
    }

    /*
    *
    * Establish the relationship between property_unit and unit_expense
    *
    */

    public function unitExpense()
    {
        return $this->hasMany('App\unitExpense'); // a unit can have 0 or many expenses 
    }
    

    /*
    *
    * Establish the relationship between property_unit and lease
    *
    */

    public function lease()
    {
        return $this->hasOne('App\lease'); // a unit is attached to 0 or 1 lease
    }
}
