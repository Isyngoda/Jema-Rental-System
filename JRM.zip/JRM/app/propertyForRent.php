<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use propertyUnit; // import the required model class

use propertyAddress; // import the required model class

use propertyGeneralExpense; // imprort the required model class

use lease; // import the required model class

use propertyMonthlyTransaction; // import the required model class

class propertyForRent extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined

    /*
    *
    * Establish the relationship between proprty_for_rent and property_unit
    *
    */

    public function propertyUnit()
    {
        return $this->hasMany('App\propertyUnit'); // a single property might have 1 or more property units
    }

    /*
    *
    * Establish the relationship between proprty_for_rent and general_expense
    *
    */

    public function propertyGeneralExpense()
    {
        return $this->hasMany('App\propertyGeneralExpense'); // a single property_for_rent has 0 or more general expenses
    }

    /*
    *
    * Establish the relationship between proprty_for_rent and lease
    *
    */

    public function lease()
    {
        return $this->hasOne('App\lease'); // a single property might have 0 or 1 lease
    }

    /*
    *
    * Establish the relationship between proprty_for_rent and property_monthly_transaction
    *
    */

    public function propertyMonthlyTransaction()
    {
        return $this->hasOne('App\propertyMonthlyTransaction'); // a single property for rent might have 1 or 0 monthly transaction
    }




    
}
