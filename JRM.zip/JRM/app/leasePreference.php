<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use lease; // import the required model class

class leasePreference extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined
    

    /*
    *
    * Establish the inverse relationship between lease_preferences and lease 
    *
    */

    public function lease()
    {
        return $this->belongsTo('App\lease'); // a preference is in a certain lease
    }
}
