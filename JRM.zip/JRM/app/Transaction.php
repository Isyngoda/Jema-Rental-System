<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\Tenant;

use App\Property;

class Transaction extends Model
{
  protected $fillable = ['tenantId', 'propertyId', 'unit', 'transType', 'payDate', 'lease',
  'startDate', 'endDate', 'category', 'amount'  ];

  public function tenant()
 {
     return $this->belongsTo('App\Tenant','tenantId');
 }

 public function property()
 {
     return $this->belongsTo('App\Property', 'propertyId');
 }
}
