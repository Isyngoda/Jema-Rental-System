<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use propertyForRent; // import the required model class

use neModelTenant; // import the required model class

class propertyMonthlyTransaction extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined
    
    /*
    *
    * Establish the reverse relationship between property_monthly_transactioin and proprty_for_rent
    *
    */

    public function propertyForRent()
    {
        return $this->belongsTo('App\propertyForRent'); // a transaction is of a property for rent
    }

    /*
    *
    * Establish the inverse relationship between property_monthly_transaction and tenant
    *
    */

    public function newModelTenant()
    {
        return $this->belongsTo('App\newModelTenant'); // a transaction is paid by a tenant
    }
}
