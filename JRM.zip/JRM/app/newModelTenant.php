<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use lease; // import the required model class

use unitMonthlyTransaction; // import the required model class

use propertyMonthlyTransaction; // import the required model class

class newModelTenant extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined
    
    /*
    *
    * Establish the relationship between tenant and unit_monthly_transaction
    *
    */

    public function unitMonthlyTransaction()
    {
        return $this->hasMany('App\unitMonthlyTransaction'); // a tenant can do 1 or more unit_monthly_transaction
    }

    /*
    *
    * Establish the relationship between tenant and property_monthly_transaction
    *
    */

    public function propertyMonthlyTransaction()
    {
        return $this->hasMany('App\propertyMonthlyTransaction'); // a tenant can do 1 or more property_mothly_transaction
    }

    /*
    *
    * Establish the relationship between tenant and lease
    *
    */

    public function lease()
    {
        return $this->hasMany('App\lease'); // a tenant can hold 1 or more leases
    }
}

