<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use propertyForRent; // import the required model class

use propertyUnit; // import the required model class

use leasePreference; // import the required model class

class lease extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined

    /*
    *
    * Establish the reverse relationship between lease and proprty_for_rent
    *
    */

    public function propertyForRent()
    {
        return $this->belongsTo('App\propertyForRent'); // a lease is attached to a property_for_rent
    }

    /*
    *
    * Establish the inverse relationship between lease and property_unit
    *
    */

    public function propertyUnit()
    {
        return $this->belongsTo('App\propertyUnit');  // a lease is attached to a property_unit
    }

    /*
    *
    * Establish the relationship between lease and if any, preferences
    *
    */

    public function leasePreference()
    {
        return $this->hasMany('App\leasePreference'); // a lease might have 0 or many lease preferences from a tenant
    }

    /*
    *
    * Establish the inverse relationship between lease and tenant
    *
    */

    public function newModelTenant()
    {
        return $this->belongsTo('App\newModelTenant'); // a lease is held by a tenant
    }
}

