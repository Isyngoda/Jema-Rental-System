<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use propertyForRent; // import the required model class

class propertyGeneralExpense extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined

    /*
    *
    * Establish the reverse relationship between property_general_expense and proprty_for_rent
    *
    */

    public function propertyForRent()
    {
        return $this->belongsTo('App\propertyForRent');
    }
    
}
