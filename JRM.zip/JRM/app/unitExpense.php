<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use propertyUnit; // import the required model class

class unitExpense extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined
    
    /*
    *
    * Establish the inverse relationship between unit_expense and property_unit
    *
    */

    public function propertyUnit()
    {
        return $this->belongsTo('App\propertyUnit'); // an expense is of a certain unit
    }
}
