<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use propertyUnit; // import the required model class

class unitMonthlyTransaction extends Model
{
    protected $guarded = []; // this means all the model attributes can be mass assgined
    
    /*
    *
    * Establish the inverse relationship between unit_monthly_transaction and property_unit
    *
    */

    public function propertyUnit()
    {
        return $this->belongsTo('App\propertyUnit'); // a monthly transaction of a certain unit
    }

    /*
    *
    * Establish the inverse relationship between unit_monthly_transaction and tenant
    *
    */

    public function tenant()
    {
        return $this->belongsTo('App\tenant'); // a monthly transaction paid by a tenant
    }
}
