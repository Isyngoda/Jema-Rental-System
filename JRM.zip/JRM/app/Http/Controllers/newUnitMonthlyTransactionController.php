<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\unitMonthlyTransaction; // import the required model class

use App\newModelTenant; // import the required model class

use App\propertyForRent; // import the required model class

use DB; // import query builder

use App\propertyUnit; // import the required model class

class newUnitMonthlyTransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $unitIncomes = unitMonthlyTransaction::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $tenant = newModelTenant::select('id', DB::raw("concat(first_name, ' ' , last_name) as full_name"))->pluck('full_name' , 'id');
        
        $property = propertyForRent::pluck('property_name' , 'id');

        $unit = propertyUnit::pluck('unit_type', 'id'); 

        return view('transactions.income.unit.create', compact('tenant', 'property', 'unit'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // validate the incoming data

        $request->validate([
            'newModelTenant_id' => 'required',
            'unit_id' => 'required',
            'property_id' => 'required',
            'transaction_type' => 'required',
            'from' => 'required',
            'to' => 'required',
            'category' => 'required',
            'amount_received' => 'required',
            'date_of_transaction' => 'required',
        ]); 

        $newUnitIncome = new unitMonthlyTransaction(); // create a new object

        // fetch a required tenant record

        $tenant = newModelTenant::select(DB::raw("concat(first_name, ' ' , last_name) as full_name"))->where('id', $request->newModelTenant_id)->first();
        
        // fetch the required record using id

        $unit = propertyUnit::select('unit_type')->where('id', $request->unit_id)->first();

        // fetch the required property using id

        $property = propertyForRent::select('property_name')->where('id', $request->property_id)->first();

        // now lets assign the values into proper columns

        $newUnitIncome->unit = $unit['unit_type'];  // the unit type

        $newUnitIncome->newModelTenant = $tenant['full_name']; // tenant

        $newUnitIncome->property = $property['property_name']; // property name

        $newUnitIncome->transaction_type = $request->transaction_type; // transaction type

        $newUnitIncome->from = $request->from; // from when will this amount hold

        $newUnitIncome->to = $request->to; // to when will this amount hold

        $newUnitIncome->category = $request->category; // is it rent or a penalty

        $newUnitIncome->amount_received = $request->amount_received; // amount received from tenant

        $newUnitIncome->date_of_transaction = $request->date_of_transaction; // transaction date

        $newUnitIncome->save(); // persist the record into the database

        return redirect()->route('transactions.index')
         ->with('success','unit transactinon added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
