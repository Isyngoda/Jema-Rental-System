<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Transaction; // import the required model class

use App\Property; // import the required model class

use App\Tenant; // import the required model class

use DB; // import the required model class

use App\unitMonthlyTransaction; // import the required model class

use App\unitExpense; // import the required model class

use App\propertyMonthlyTransaction;  // import the required model class

use App\propertyGeneralExpense; // import the required model class

use App\propertyForRent;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // sum the amount_received column then store it in a variable and get the total unit expenses

       $totalUnitIncomes = unitMonthlyTransaction::sum('amount_received');

       $totalUnitExpenses = unitExpense::sum('amount_involved');

       // get the number of unit income transactions and expenses

       $numberOfUnitIncomes = unitMonthlyTransaction::count();

       $numberOfUnitExpenses = unitExpense::count(); 

       // get the total of property income transactions and get the total property expenses

       $totalPropertyIncomes = propertyMonthlyTransaction::sum('amount_received');

       $totalPropertyExpenses = propertyGeneralExpense::sum('amount_involved');

       // get the number of property income transactions and expenses

       $numberOfPropertyIncomes = propertyMonthlyTransaction::count();

       $numberOfPropertyExpenses = propertyGeneralExpense::count();

       // get the total number of unit and property incomes

       $numberOfIncomeTransactions = $numberOfUnitIncomes + $numberOfPropertyIncomes;

       // get the total number of unit and property expenses

       $numberOfExpenseTransactions = $numberOfUnitExpenses + $numberOfPropertyExpenses;

       // get the total number of transactions (both incomes and expenses for both units and properties)

       $totalNumberOfAllTransactions = $numberOfIncomeTransactions + $numberOfExpenseTransactions;

       // get the sum of unit and property transactions

       $totalIncomeTransactions = $totalUnitIncomes + $totalPropertyIncomes; // all incomes (units and properties)

       $totalExpenseTransactions = $totalUnitExpenses + $totalPropertyExpenses; // all expenses(units and properties)

       $valueDifference =  $totalIncomeTransactions - $totalExpenseTransactions; // profit or loss

       $valueDifference = number_format($valueDifference, 2); // format the difference

       $totalIncomeTransactions = number_format($totalIncomeTransactions, 2); // format the difference

       $totalExpenseTransactions = number_format($totalExpenseTransactions, 2); // format the difference

       // lets get a list of all transactions
       $unitIncomes = unitMonthlyTransaction::all(); 

       $unitExpenses = unitExpense::all();

       $propertyIncomes = propertyMonthlyTransaction::all();

       $propertyExpenses = propertyGeneralExpense::all();

      return view('transactions.index',compact('totalIncomeTransactions','totalExpenseTransactions','valueDifference','totalNumberOfAllTransactions',
    'unitIncomes', 'unitExpenses', 'propertyIncomes', 'propertyExpenses'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $tenant = Tenant::select('id', DB::raw("concat(fname, ' ' , lname) as full_name"))->pluck('full_name' , 'id');

      $property = Property::pluck('propName' , 'id');

      return view('transactions.income.create', compact(['tenant', 'property']));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
