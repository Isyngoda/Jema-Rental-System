<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\propertyForRent; // import a required model class

use App\newModelTenant; // import a required model class

use App\propertyMonthlyTransaction; // import a required model class

use DB; // import query builder 

use App\propertyUnit; // import a required model class

class newPropertyMonthlyTransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $tenant = newModelTenant::select('id', DB::raw("concat(first_name, ' ' , last_name) as full_name"))->pluck('full_name' , 'id');
        
        $property = propertyForRent::pluck('property_name' , 'id');

        return view('transactions.income.property.create', compact('tenant', 'property'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // validate the incoming data

        $request->validate([
            'newModelTenant_id' => 'required',
            'property_id' => 'required',
            'transaction_type' => 'required',
            'from' => 'required',
            'to' => 'required',
            'category' => 'required',
            'amount_received' => 'required',
            'date_of_transaction' => 'required',
        ]); 

        $newPropertyIncome = new propertyMonthlyTransaction(); // create a new object

        // fetch a tenant record using id

        $tenant = newModelTenant::select(DB::raw("concat(first_name, ' ' , last_name) as full_name"))->where('id', $request->newModelTenant_id)->first();
        
        // fetch the required property using id

        $property = propertyForRent::select('property_name')->where('id', $request->property_id)->first();

        // now lets assign the values into proper columns

        $newPropertyIncome->property = $property['property_name']; // assign property_name

        $newPropertyIncome->newModelTenant = $tenant['full_name']; // assign tenant's name

        $newPropertyIncome->transaction_type = $request->transaction_type; // assign transaction type

        $newPropertyIncome->date_of_transaction = $request->date_of_transaction; // assign a date of transaction

        $newPropertyIncome->category = $request->category; // assign a category

        $newPropertyIncome->from = $request->from; // assign a start date

        $newPropertyIncome->to = $request->to; // assign a to date

        $newPropertyIncome->amount_received = $request->amount_received; // assign amount received

        $newPropertyIncome->save(); // persist the record to the database

        return redirect()->route('transactions.index')
        ->with('success','unit transactinon added successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
