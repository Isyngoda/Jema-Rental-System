<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request; // import the request class

use App\newModelTenant; // import the required model class

class newTenantController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tenants = newModelTenant::all(); // query all the tenants records 

        return view('tenant.index',compact('tenants'));  // return the required view and data
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tenant.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate([
            'first_name'    => 'required',
            'middle_name'   => 'required',
            'last_name'     => 'required',
            'email'         => 'required',
            'date_of_birth' => 'required',
            'sex'      => 'required',
            'phone'   => 'required',
            ]);

            newModelTenant::create($request->all()); // create a new tenant record

          return redirect()->route('tenants.index')->with('success','Tenant created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $tenant = newModelTenant::find($id);

        return view('tenant.view',compact('tenant'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $tenant = newModelTenant::find($id);
        
        return view('tenant.edit',compact('tenant'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // validate the incoming data

        $request->validate([
        'first_name'    => 'required',
        'middle_name'   => 'required',
        'last_name'     => 'required',
        'email'         => 'required',
        'date_of_birth' => 'required',
        'sex'      => 'required',
        'phone'   => 'required',
        ]); 

        // fetch the record to be updated

        $tenantToUpdate = newModelTenant::find($id);

        // update the record

        $tenantToUpdate->update($request->all());

        $tenantToUpdate->save();

        //redirect the user

        return redirect()->route('tenants.index')->with('success','Tenant record updated successfully');
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        newModelTenant::find($id)->delete();
        
        return redirect()->route('tenants.index')
                                ->with('success','Tenant deleted successfully');
    }
}
