<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class reportController extends Controller
{
    public function index()
    {
      return view('report.index');
    }

    public function expenseReport()
    {
      return view ('report.expense-report');
    }

    public function leaseStatement()
    {
      return view ('report.lease-statement');
    }

    public function monthlyProperty()
    {
      return view ('report.monthly-property');
    }

    public function operatingReport()
    {
      return view ('report.operating-report');
    }
}
