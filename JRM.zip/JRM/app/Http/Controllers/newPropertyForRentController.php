<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\propertyForRent;    // import the required model class

use App\propertyAddress; // import the required model class

use App\propertyUnit; // import the required model class

class newPropertyForRentController extends Controller
{
    /**
     * Display a listing of the resource
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $properties = propertyForRent::get(); // fetch all property records
        
        return view('property.index',compact('properties'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('property.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // validate the incoming request before storing the data

      $formInput = $request->except('profile');

      request()->validate([
        'propName'  => 'required',
        'plotNo'    => 'required',
        'blockNo'    => 'required',
        'propType'  => 'required',
        'street'    => 'required',
        'region'    => 'required',
      ]);

        $newlyCreatedProperty = new PropertyForRent(); // create a new instance of class property

        $newlyCreatedProperty->property_name = $request->propName; // assign the property's name

        $newlyCreatedProperty->property_type = $request->propType; // assign street

        $profile = $request->profile; // assign the image object into another variable
        
        if($profile) // if the variable is set
        {
        
            $profileImage = $profile->getClientOriginalName(); // store the profile image name
            
            $profile->move('propertyImages',$profileImage); //move the image into a required folder
            
            $newlyCreatedProperty->profile = $profileImage; // store the image name in the database
        
        }

        $newlyCreatedProperty->plot_no = $request->plotNo; // plot number
        
         $newlyCreatedProperty->block_no = $request->blockNo; // block number
        
         $newlyCreatedProperty->street = $request->street; // street
                
         $newlyCreatedProperty->region = $request->region; // region
        
         $newlyCreatedProperty->save(); // save the newly created address record
        
        // count the number of array elements in the given array

        $numberOfElementsInArray = count($request -> unit_no);
        
        // loop through all the elements in the array

        for($i = 0; $i<$numberOfElementsInArray-1; $i++)
        {
            // create and instante a new unit object

            $newlyCreatedUnit = new propertyUnit(); // create the object

            $newlyCreatedUnit->property_id = $newlyCreatedProperty->id; // assign its property_id value

            $newlyCreatedUnit->unit_no = $request->unit_no[$i]; // assign its unit_no value

            $newlyCreatedUnit->unit_type = $request->unit_type[$i]; // assign its unit_type value

            $newlyCreatedUnit->fixed_monthly_rent = $request->unit_rent[$i]; // assign its unit_rent value

            $newlyCreatedUnit->save(); // persist the newly created unit object to the database

        }

        $properties = propertyForRent::all();

        return view('property.index', compact('properties'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $property = propertyForRent::find($id); // get the required property

        $units = propertyUnit::where('property_id', $property->id)->get(); // get all the property's units

        return view('property.view',compact('property', 'units')); // return the required view 
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $property = propertyForRent::find($id);

        return view('property.edit',compact('property'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
            'property_name'  => 'required',
            'plot_no'    => 'required',
            'block_no'    => 'required',
            'street'    => 'required',
            'region'    => 'required',
            'property_type' => 'required',
            'fixed_monthly_rent' => 'required',
          ]);

          $profile = $request->profile; // get ans store the object

          if($profile)  // check to see if an image was chosen for upload
          {
            $profile->move('propertyImages',$profile->getClientOriginalName()); // move the object into the required folder
            
            $request->profile = $profile->getClientOriginalName();  // store just the name of the incomiing object
          }
          
         
         $propertyToUpdate = propertyForRent::where('id', $id)->first();

         $propertyToUpdate->update($request->except('status')); // not stored in the database

         $propertyToUpdate->profile = $profile->getClientOriginalName();

         $propertyToUpdate->save();
 
          return redirect()->route('properties.index')
                          ->with('success','Property updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        propertyForRent::find($id)->delete();
        
        return redirect()->route('properties.index')
                                ->with('success','Property deleted successfully');
    }
}
