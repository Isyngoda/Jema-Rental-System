<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/', 'DashboardController@index')->name('dashboard');

Route::resource('properties', 'newPropertyForRentController');

Route::resource('tenants', 'newTenantController');

Route::resource('unitMonthlyTransactions', 'newUnitMonthlyTransactionController');

Route::resource('unitExpenses', 'newUnitExpenseController');

Route::resource('propertyMonthlyTransactions', 'newPropertyMonthlyTransactionController');

Route::resource('propertyGeneralExpenses', 'newGeneralExpenseController');

Route::resource('expenses', 'ExpenseController');

Route::resource('transactions', 'TransactionController');

Route::get('reports', 'reportController@index')->name('report');

Route::get('expense-report', 'reportController@expenseReport')->name('expenseReport');

Route::get('lease-statement', 'reportController@leaseStatement')->name('leaseStatement');

Route::get('monthly-property', 'reportController@monthlyProperty')->name('monthlyProperty');

Route::get('operating-report', 'reportController@operatingReport')->name('operatingReport');
