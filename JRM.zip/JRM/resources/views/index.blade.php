@extends('layouts.header')

@section('content')

  <div class="content">
    <div class="container-fluid">
      <div class="row">
              <div class="col-md-4">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Quick Buttons</h4>
                          <p class="category">Sub heading goes here</p>
                      </div>
                      <div class="content all-icons">
                          <div class="row">
                              <!-- add new property -->
                              <a class="quick-links" href="{{route('properties.create')}}">
                                <div class="font-icon-list col-lg-6 col-md-6 col-sm-6 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <i class="pe-7s-home"></i>
                                      <p>ADD NEW PROPERTY</p>
                                  </div>
                                </div>
                              </a>
                              <!-- / -->
                              <!-- add new expense -->
                              <a class="quick-links" href="{{route('unitExpenses.create')}}">
                                <div class="font-icon-list col-lg-6 col-md-6 col-sm-6 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <i class="pe-7s-cash"></i>
                                      <p>ADD NEW EXPENSE</p>
                                  </div>
                                </div>
                              </a>
                              <!-- / -->
                              <!-- add new tenant -->
                              <a class="quick-links" href="{{route('tenants.create')}}">
                                <div class="font-icon-list col-lg-6 col-md-6 col-sm-6 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <i class="pe-7s-user"></i>
                                      <p>ADD NEW TENANT</p>
                                  </div>
                                </div>
                              </a>
                              <!-- / -->
                              <!-- add new income -->
                              <a class="quick-links" href="{{route('unitMonthlyTransactions.create')}}">
                                <div class="font-icon-list col-lg-6 col-md-6 col-sm-6 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <i class="pe-7s-cash"></i>
                                      <p>ADD NEW INCOME</p>
                                  </div>
                                </div>
                              </a>
                            <!-- / -->
                          </div>
                      </div>

                  </div>
              </div>
              <div class="col-md-4">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Units</h4>
                          <p class="category">Total number of units occupied and vacant</p>
                      </div>
                      <div class="content">
                          <div id="chartPreferences" class="ct-chart ct-perfect-fourth" style="height: 240px; margin: 0 0 30px;"></div>

                          <div class="footer">
                              <div class="legend">
                                  <i class="fa fa-circle text-info"></i> Occupied
                                  <i class="fa fa-circle text-danger"></i> Vacant
                              </div>
                              <hr>
                              <div class="stats">
                                  <i class="fa fa-clock-o"></i> Campaign sent 2 days ago
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="col-md-4">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Last 30 Days</h4>
                          <p class="category">Paid Invoce and Pending payments</p>
                      </div>
                      <div class="content all-icons">
                          <div class="row">
                              <!-- add new property -->
                              <a class="quick-links" href="" title="Click to View All">
                                  <div class="font-icon-list col-lg-12 col-md-12 col-sm-12 col-xs-6 col-xs-6">
                                      <div class="font-icon-detail">
                                          <h3>TZS 200,000/=</h3>
                                          <p>Paid Invoices</p>
                                      </div>
                                  </div>
                              </a>
                              <!-- / -->
                              <!-- add new income -->
                              <a class="quick-links" href="" title="Click to View All">
                                  <div class="font-icon-list col-lg-12 col-md-12 col-sm-12 col-xs-6 col-xs-6">
                                      <div class="font-icon-detail">
                                          <h3>TZS 0 </h3>
                                          <p>Pending Payments</p>
                                      </div>
                                  </div>
                              </a>
                              <!-- / -->
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <div class="row">

              <div class="col-md-8">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Lease Expires in 2 Weeks</h4>
                          <p class="category">Here is a subtitle for this table</p>
                      </div>
                      <div class="content table-responsive table-full-width">
                          <table class="table table-hover">
                              <thead>
                                  <th>Name</th>
                                  <th>Property Name</th>
                                  <th>Room No #</th>
                                  <th>Expire Date</th>
                                  <th>Action</th>
                              </thead>
                              <tbody>
                                  <tr>
                                      <td>Evans Tarimo</td>
                                      <td>Seedfarm B</td>
                                      <td>1</td>
                                      <td>10 Nov 2017</td>
                                      <td><a href="" class="btn btn-success">pay</a></td>
                                  </tr>
                                  <tr>
                                      <td>Israel Ngoda</td>
                                      <td>Seedfam A</td>
                                      <td>5</td>
                                      <td>20 Nov 2017</td>
                                      <td><a href="" class="btn btn-success">pay</a></td>
                                  </tr>
                                  <tr>
                                      <td>Alferio Njau</td>
                                      <td>Mahenge</td>
                                      <td>2</td>
                                      <td>15 Nov 2017</td>
                                      <td><a href="" class="btn btn-success">pay</a></td>
                                  </tr>
                                  <tr>
                                      <td>Najim Saleh</td>
                                      <td>Msamala</td>
                                      <td>3</td>
                                      <td>16 Nov 2017</td>
                                      <td><a href="" class="btn btn-success">pay</a></td>
                                  </tr>
                              </tbody>
                          </table>
                          <div class="footer" style="text-align: end; margin-right: 10px;">
                              <div class="stats">
                                  <a href="" class="btn btn-primary">More...</a>
                              </div>
                          </div>

                      </div>
                  </div>
              </div>
          </div>
      </div>
    </div>


@endsection
