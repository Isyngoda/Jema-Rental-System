@extends('layouts.header')

@section('breadcrumb')

  <a href="{{ route('transactions.index') }}">Accounting</a>

@stop

@section('content')

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="col-md-12">
                        <div class="header">
                            <div class="col-md-8">
                                <div class="row">
                                    <h4 class="title">All Transactions</h4>
                                </div>
                            </div>
                            <div class="col-md-2">

                                <a class="btn btn-success" href="{{route('unitMonthlyTransactions.create')}}">+ Add new Income</a>
                            </div>
                            <div class="col-md-2">
                                <a class="btn btn-danger" href="{{route('unitExpenses.create')}}">+ Add new Expense</a>
                            </div>
                        </div>
                    </div>
                    <div class="content all-icons">

                        <div class="row">
                            <div class="font-icon-list col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xs-6">
                                <div class="font-icon-detail">
                                    <p>Total Number of Transactions <br /><br /><h5>{{ $totalNumberOfAllTransactions}}</h5> </p>
                                    <h3></h3>
                                </div>
                            </div>
                            <div class="font-icon-list col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xs-6">
                                <div class="font-icon-detail">
                                    <p>Total Income</p>
                                    <h3>Tsh {{$totalIncomeTransactions}}</h3>
                                </div>
                            </div>
                            <div class="font-icon-list col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xs-6">
                                <div class="font-icon-detail">
                                    <p>Total Expense</p>
                                    <h3>Tsh {{$totalExpenseTransactions}}</h3>
                                </div>
                            </div>

                            <div class="row">
                            <div class="font-icon-list col-lg-3 col-md-3 col-sm-3 col-xs-6 col-xs-6">
                                <div class="font-icon-detail">
                                @if($valueDifference > 0)
                                    <h3>Profit <br /><br />{{$valueDifference}}</h3>
                                @else
                                    <h3>Loss <br /><br />{{$valueDifference}}</h3>
                                @endif
                                </div>
                            </div>
                        </div>

                          <hr>

                          <div class="row">
                              <div class="col-md-12">
                                  <div class="content table-responsive table-full-width">
                                      <table class="table table-hover">
                                          <thead>
                                              <th>Status</th>
                                              <th>Person</th>
                                              <th>Space</th>
                                              <th>Total/Paid</th>
                                              <th>Date of transaction</th>
                                              <th>Transaction</th>
                                              <th>Action</th>
                                          </thead>
                                          <tbody>

                                       @foreach($unitIncomes as $unitIncome)
                                              <tr>
                                                  <td><span class="label label-success">PAID</span></td>
                                                  <td><br> <small>{{$unitIncome->newModelTenant}}<a href=""></a></small></td>
                                                  <td>Unit</td>
                                                  <td>{{$unitIncome->amount_received}}</td>
                                                  <td>{{$unitIncome->date_of_transaction}}</td>
                                                  <td>Income</td>
                                                  <td>
                                                      <a href="" class="btn btn-primary">Details</a>
                                                  </td>
                                              </tr>
                                        @endforeach

                                        @foreach($unitExpenses as $unitExpense)
                                              <tr>
                                                  <td><span class="label label-danger">PAID</span></td>
                                                  <td><br> <small>{{$unitExpense->tenant}}<a href=""></a></small></td>
                                                  <td>Unit</td>
                                                  <td>{{$unitExpense->amount_involved}}</td>
                                                  <td>{{$unitExpense->date_incurred}}</td>
                                                  <td>Expense</td>
                                                  <td>
                                                      <a href="" class="btn btn-primary">Details</a>
                                                  </td>
                                              </tr>
                                        @endforeach

                                        @foreach($propertyIncomes as $propertyIncome)
                                              <tr>
                                                  <td><span class="label label-success">PAID</span></td>
                                                  <td><br> <small>{{$propertyIncome->newModelTenant}}<a href=""></a></small></td>
                                                  <td>Property</td>
                                                  <td>{{$propertyIncome->amount_received}}</td>
                                                  <td>{{$propertyIncome->date_of_transaction}}</td>
                                                  <td>Income</td>
                                                  <td>
                                                      <a href="" class="btn btn-primary">Details</a>
                                                  </td>
                                              </tr>
                                        @endforeach

                                        @foreach($propertyExpenses as $propertyExpense)
                                              <tr>
                                                  <td><span class="label label-danger">PAID</span></td>
                                                  <td><br> <small>{{$propertyExpense->tenant}}<a href=""></a></small></td>
                                                  <td>Property</td>
                                                  <td>{{$propertyExpense->amount_involved}}</td>
                                                  <td>{{$propertyExpense->date_incurred}}</td>
                                                  <td>Expense</td>
                                                  <td>
                                                      <a href="" class="btn btn-primary">Details</a>
                                                  </td>
                                              </tr>
                                        @endforeach



                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

@endsection
