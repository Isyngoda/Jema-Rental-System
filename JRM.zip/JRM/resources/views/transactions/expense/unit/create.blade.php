@extends('layouts.header')

@section('content')
  <div class="content">
      <div class="container-fluid">
          <div class="row">
          <div class="col-md-2">
                    <a class="btn btn-danger" href="{{route('unitExpenses.create')}}">+ Add Unit Expense</a>
                </div>
                                            
                <div class="col-md-2">
                    <a class="btn btn-danger" href="{{route('propertyGeneralExpenses.create')}}">+ Add Property Expense</a>
                </div>
                <br/><br /><hr/>
              <div class="col-md-12">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Add Unit Expense</h4>
                      </div>
                      <div class="content all-icons">
                          {!! Form::open(array('route' => 'unitExpenses.store','method'=>'POST')) !!}
                              <div class="row">
                                  <div class="col-md-5">
                                      <div class="form-group">
                                          <label value="tenantId">Payer / Payee</label>
                                          {!!Form::select('newModelTenant_id', $tenant, null, array('class'=>'form-control', 'placeholder'=>'Select Tenant'))!!}
                                      </div>
                                  </div>
                                  
                                  <div class="col-md-3">
                                      <div class="form-group">
                                          <label>Unit</label>
                                          {!!Form::select('unit_id', $unit, null, array('class'=>'form-control', 'placeholder'=>'Select Unit'))!!}
                                     </div>
                                  </div>

                                  <div class="col-md-4">
                                      <div class="form-group">
                                          <label value="propertyId">Property</label>
                                          {!!Form::select('property_id', $property, null, array('class'=>'form-control', 'placeholder'=>'Select Property'))!!}
                                      </div>
                                  </div>

                              </div>

                              <div class="row">
                                  <div class="col-md-12">
                                      <div class="content table-responsive table-full-width">
                                          <table class="table table-hover table-striped">
                                              <thead>
                                                  <th>Date incurred</th>
                                                  <th>Category</th>
                                                  <th>Amount involved</th>
                                                  <th>Transaction type</th>
                                              </thead>
                                              <tbody>
                                                  <tr>
                                                      <td>
                                                        {!! Form::date('date_incurred', null, array('placeholder' => 'End Date','class' => 'form-control')) !!}
                                                      </td>
                                                      <td>
                                                        {!!Form::select('category', ['Plumbing' => 'Plumbing', 'Electricity' => 'Electricity'], null, array('class'=>'form-control', 'placeholder'=>'Select Category'))!!}
                                                      </td>
                                                      <td>
                                                        {!! Form::text('amount_involved',  null, array('placeholder' => 'Amount','class' => 'form-control')) !!}
                                                      </td>
                                                      <td>
                                                         {!!Form::select('transaction_type',['cash' => 'Cash', 'credit' => 'Credit'], null, array('class'=>'form-control', 'placeholder'=>'Select transaction type'))!!}
                                                      </td>
                                                    
                                                  </tr>
                                              </tbody>
                                          </table>
                                      </div>
                                  </div>
                              </div>

                              <input type="submit" class="btn btn-warning btn-fill pull-right"></button>
                              <div class="clearfix"></div>

                           <div class="clearfix"></div>
                          {!! Form::Close() !!}
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
@endsection
