@extends('layouts.header')

@section('breadcrumb')

  Tenants

@stop

@section('content')
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <div class="col-md-10">
                            <div class="row">
                                <h4 class="title">All Tenants</h4>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <a class="btn btn-primary" href="{{route('tenants.create')}}">+ Add new tenant</a>
                        </div>
                    </div>
                    <div class="content" style="margin-top: 40px;">
                        <div class="row">
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email:</th>
                                        <th>Phone</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        @foreach ($tenants as $tenant)
                                        <tr>
                                            <td>{{$tenant -> first_name}}</td>
                                            <td>{{$tenant -> last_name}}</td>
                                            <td>{{$tenant -> email }}</td>
                                            <td>{{$tenant -> phone }}</td>
                                
                                            <td width="20%">
                                                <a href="{{route('tenants.show', $tenant -> id)}}" class="btn btn-info" title="View More Information"><i class="fa fa-eye"></i></a>
                                                <a href="{{ route('tenants.edit',$tenant->id) }}" class="btn btn-warning" title="Edit tenant information"><i class="fa fa-edit"></i></a>
                                                {!! Form::open(['method' => 'DELETE','route' => ['tenants.destroy', $tenant->id],'style'=>'display:inline']) !!}
                                                {!! Form::submit('X',['class' => 'btn btn-danger']) !!}
                                                {!! Form::close() !!}
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
