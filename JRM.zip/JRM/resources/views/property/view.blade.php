@extends ('layouts.header')

@section('breadcrumb')
  
  <a href="{{route('properties.index')}}">Properties</a>

@stop

@section('breadcrumb2')
  
  {{ $property -> propName}}

@stop

@section('content')
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="header">
                        <h4 class="title">{{ $property -> property_name}}</h4>
                    </div>
                    <div class="content">
                        <h5 class="title">Summary of Financials</h5>
                        
                        <div id="chartHours" class="ct-chart"></div>
                        
                        <div class="footer">
                            <div class="legend">
                                <i class="fa fa-circle text-success"></i> Income
                                <i class="fa fa-circle text-danger"></i> Expenses
                            </div>
                        </div>
                        
                        <hr>

                        <h5 class="title">Units</h5>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="content table-responsive table-full-width">
                               
                                    <table class="table table-hover table-striped">
                                    @if(!empty($units))
                                        <thead>
                                            <th>Unit No:</th>
                                            <th>Unit Type</th>
                                            <th>Fixed Monthly Rent</th>
                                            <th>Occupied</th>
                                            <th>Tenant</th>
                                            <th>Action</th>
                                        </thead>
                                        <tbody>
                                         @foreach($units as $unit)
                                            <tr>
                                                <td>{{ $unit->unit_no }}</td>
                                                <td>{{ $unit->unit_type}}</td>
                                                <td>{{ $unit->fixed_monthly_rent}}</td>
                                                @if(!empty($unit->occupied))
                                                  <td>{{ $unit->occupied}}</td>
                                                @else
                                                  <td>No</td>
                                                @endif
                                                <td>Default</td>
                                                <td><a href="" class="btn btn-primary">View Unit</a></td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                        @elseif(empty($units))
                                           <p>This property has no units</p>
                                         @endif
                                    </table>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-user">
                    <div class="image">
                        <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt=""/>
                    </div>
                    <div class="content">
                        <div class="author">
                            <a href="{{route('properties.show', $property->id)}}" title="View Property">
                                <img class="avatar border-gray" src="{{ url('propertyImages', $property->profile) }}" alt=""/>
                                                    
                                <h4 class="title">{{$property -> propName}}<br />
                                    <small>Plot No: {{$property -> plot_no}}, Block No: {{$property ->block_no}}</small>
                                    <br /><small>Street: {{$property -> street}} <br /> Region: {{$property -> region}}</small>
                                </h4>
                            </a>
                        
                            <p class="description text-center">
                                
                            </p>
                            <a class="btn btn-primary" href="{{ route('properties.edit',$property->id) }}">Edit</a>
                            {!! Form::open(['method' => 'DELETE','route' => ['properties.destroy', $property->id],'style'=>'display:inline']) !!}
                            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
