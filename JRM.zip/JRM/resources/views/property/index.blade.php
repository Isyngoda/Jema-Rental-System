@extends('layouts.header')

@section('breadcrumb')

  Properties

@stop

@section('content')

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <div class="col-md-10">
                            <div class="row">
                                <h4 class="title">All Properties</h4>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <a class="btn btn-primary" href="{{route('properties.create')}}">+ Add new property</a>
                        </div>
                    </div>
                    @if(!empty($properties))
                      @foreach ($properties as $property)
                      <div class="content">
                        <div class="row">

                            <div class="col-md-4" style="margin-top: 15px;">
                                <div class="card card-user">
                                    <div class="image">
                                        <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt=""/>
                                    </div>
                                    <div class="content">
                                        <div class="author">
                                            <a href="{{route('properties.show', $property->id)}}" title="View Property">
                                                <img class="avatar border-gray" src="{{url('propertyImages', $property->profile)}}" alt=""/>

                                                <h4 class="title">{{$property->property_name}}<br />
                                                    <small>Plot No: {{$property->plot_no}}, Block No: {{$property ->block_no}}</small><br />
                                                    <small>Street: {{$property->street}},  Region: {{$property ->region}}</small>

                                                </h4>
                                            </a>
                                        </div>
                    
                                    </div>
                                    <hr>
                                    <div class="text-center">
                                        <button href="#" class="btn btn-simple">
                                            <span class="label label-success">2</span> Occupied
                                        </button> |
                                        <button href="#" class="btn btn-simple">
                                            <span class="label label-warning">1</span> Vacant
                                        </button>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                  @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
