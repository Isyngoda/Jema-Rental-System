@extends('layouts.header')

@section('breadcrumb')

  <a href="{{route('properties.index')}}">Properties</a>

@stop

@section('breadcrumb2')

  Add Property

@stop

@section('content')
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Add Property</h4>
                    </div>
                    <div class="content">
                        {!! Form::open(array('route' => 'properties.store','method'=>'POST', 'files' => 'true')) !!}

                        <div class="row">
                            <div class="col-md-12">
                                <label><b>General Information</b></label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Property Name</label>
                                    {!! Form::text('propName', null, array('placeholder' => 'Property Name','class' => 'form-control')) !!}
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Plot No:</label>
                                    {!! Form::text('plotNo', null, array('placeholder' => 'Plot No','class' => 'form-control')) !!}
                                </div>

                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Block No:</label>
                                    {!! Form::text('blockNo', null, array('placeholder' => 'Block No','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Street Address</label>
                                    {!! Form::text('street', null, array('placeholder' => 'Street','class' => 'form-control')) !!}
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Region / City</label>
                                    {!! Form::text('region', null, array('placeholder' => 'Region','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>

                        <hr>

                        <div class="row">
                            <div class="col-md-12">
                                <label><b>Property Type</b></label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                {!!Form::select('propType', ['Single-Unit' => 'Single-Unit', 'Multi-Unit' => 'Multi-    Unit'],
                                null, array('class'=>'form-control', 'placeholder'=>'Select Category'))!!}
                            </div>
                        </div>

                        <hr>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Property Image</label>
                                    {!! Form::file('profile', null, array('placeholder' => 'Image','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="control-group after-add-more">
                                    <div class="form-group col-md-2" style="padding-left: 0px;">
                                        {!! Form::text('unit_no[]', null, array('placeholder' => 'Unit No:','class' => 'form-control')) !!}
                                    </div>
                                    <div class="form-group col-md-4">
                                        {!!Form::select('unit_type[]',
                                        [   'room' => 'Room',
                                        'master_room' => 'Master Room',
                                        'commercial' => 'Commercial',
                                        'storage' => 'Storage'
                                        ], null, array('class'=>'form-control', 'placeholder'=>'Select Category'))!!}
                                    </div>
                                    <div class="form-group col-md-4">
                                        {!! Form::text('unit_rent[]', null, array('placeholder' => 'Market Rent ex 10,000','class' => 'form-control')) !!}
                                    </div>
                                    <div class="form-grop col-md-2">
                                        <div class="input-group-btn">
                                            <button class="btn btn-success add-more" title="Add Another Unit" type="button"><i class="fa fa-plus-circle"></i></button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- Copy Fields -->
                        <div class="copy hide">
                            <div class="control-group" style="margin-top:5px">
                                <div class="col-md-12">
                                    <div class="row">
                                <div class="form-group col-md-2" style="padding-left: 0px;">
                                    {!! Form::text('unit_no[]', null, array('placeholder' => 'Unit No:','class' => 'form-control')) !!}
                                </div>
                                <div class="form-group col-md-4">
                                    {!!Form::select('unit_type[]',
                                    [   'room' => 'Room',
                                    'master_room' => 'Master Room',
                                    'commercial' => 'Commercial',
                                    'storage' => 'Storage'
                                    ], null, array('class'=>'form-control', 'placeholder'=>'Select Category'))!!}
                                </div>
                                <div class="form-group col-md-4">
                                    {!! Form::text('unit_rent[]', null, array('placeholder' => 'Market Rent ex 10,000','class' => 'form-control')) !!}
                                </div>
                                <div class="form-grop col-md-2">
                                    <div class="input-group-btn">
                                        <button class="btn btn-danger remove" title="Remove Unit" type="button"><i class="fa fa-trash"></i></button>
                                    </div>
                                </div>
                            </div>
                            </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-default btn-fill pull-left">Back</button>
                        <button type="submit" class="btn btn-info btn-fill pull-right">Save</button>
                        <div class="clearfix"></div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-user">
                    <div class="image">
                        <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?    fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                    </div>
                    <div class="content">
                        <div class="author">
                            <a href="#">
                                <img class="avatar border-gray" src="../assets/img/property.jpg" alt="..."/>

                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<script type="text/javascript">

    $(document).ready(function() {

      $(".add-more").click(function(){
          var html = $(".copy").html();
          $(".after-add-more").after(html);
      });

      $("body").on("click",".remove",function(){
          $(this).parents(".control-group").remove();
      });

    });

</script>

@endsection
