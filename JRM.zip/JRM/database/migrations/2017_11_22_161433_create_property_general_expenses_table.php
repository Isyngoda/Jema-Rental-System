<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePropertyGeneralExpensesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('property_general_expenses', function (Blueprint $table) {
            $table->increments('id'); // the primary key of the expense
            $table->date('date_incurred'); // the date on which the expense was incurred
            $table->decimal('amount_involved', 7, 2); // the monetary cost of the expense
            $table->string('property'); // the property that contains the unit
            $table->string('category'); // what category of purpose was the rent for ?
            $table->string('transaction_type'); // the type of transaction
            $table->string('tenant'); // tenant that paid for the expense
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('property_general_expenses');
    }
}
