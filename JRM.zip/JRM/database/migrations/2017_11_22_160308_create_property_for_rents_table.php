<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePropertyForRentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('property_for_rents', function (Blueprint $table) {
            $table->increments('id'); // the primary key
            $table->string('property_name'); // the name of the property
            $table->string('profile'); // the profile picture of the property
            $table->string('property_type'); // the type of property
            $table->date('date_of_first_usage')->nullable(); // date of first usage of property
            $table->decimal('fixed_monthly_rent', 7, 2)->nullable(); // the property's fixed monthly rate
            $table->char('occupied')->nullable(); // is the property occupied or not ?
            $table->integer('plot_no'); // the property's plot number
            $table->string('block_no'); // the property's block number
            $table->string('street'); // the property's street
            $table->string('region'); // the property's region
            $table->integer('lease_id')->nullable(); // the property's lease id
            $table->timestamps(); // the created_at and updated_at timestamps
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('property_for_rents');
    }
}
