<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePropertyUnitsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('property_units', function (Blueprint $table) {
            $table->increments('id'); // the unit's primary key
            $table->string('unit_type'); // the unit's type
            $table->integer('unit_no'); // the unit's number
            $table->decimal('fixed_monthly_rent', 7, 2); // the unit's fixed monthly rate
            $table->integer('property_id'); // property in which this property belongs
            $table->char('occupied')->nullable(); // is the unit occupied or not
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('property_units');
    }
}
