<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLeasesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('leases', function (Blueprint $table) {
            $table->increments('id'); // the primary key of the lease
            $table->string('terms_and_agreements'); // the terms and agreement of the lease
            $table->string('type'); // type of lease
            $table->date('from'); // the start of the contract
            $table->date('to'); // the end of the contract
            $table->decimal('agreed_monthly_rent', 7, 2); // the agreed rent after negotiation
            $table->integer('tenant_id'); // who owns this contract
            $table->integer('unit_id'); // lease of a unit only
            $table->integer('property_id'); // lease of a whole property
            $table->timestamps(); // the created_at and updated_at timestamps
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('leases');
    }
}
