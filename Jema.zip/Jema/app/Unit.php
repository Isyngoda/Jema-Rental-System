<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use App\Property;

class Unit extends Model
{
  protected $fillable = ['unit_no', 'unit_type', 'unit_rent'];
  public function property()
  {
    return $this->belongsTo('App\Property', 'propertyId');
  }
}
