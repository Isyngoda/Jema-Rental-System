<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\newModelTenant; // import the required model class

use App\propertyForRent; // import the required model class

use App\propertyGeneralExpense; // import the required model class

use DB;

class newGeneralExpenseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 
        $tenant = newModelTenant::select('id', DB::raw("concat(first_name, ' ' , last_name) as full_name"))->pluck('full_name' , 'id');
        
        $property = propertyForRent::pluck('property_name' , 'id'); // get the property's for the drop downs
        
        return view('transactions.expense.property.create', compact('tenant', 'property')); // return the required view
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // validate the incoming data first
        
        $request->validate([
            'newModelTenant_id' => 'required',
            'property_id' => 'required',
            'date_incurred' => 'required',
            'category' => 'required',
            'amount_involved' => 'required',
            'transaction_type' => 'required',
           ]);

           $newPropertyExpense = new propertyGeneralExpense(); // create a new object
           
           // fetch a required tenant record
           
           $tenant = newModelTenant::select(DB::raw("concat(first_name, ' ' , last_name) as full_name"))->where('id', $request->newModelTenant_id)->first();
          
           // fetch the required property using id
   
           $property = propertyForRent::select('property_name')->where('id', $request->property_id)->first();
   
           // now lets assign the values into proper columns
      
           $newPropertyExpense->tenant = $tenant['full_name']; // tenant
   
           $newPropertyExpense->property = $property['property_name']; // property name
   
           $newPropertyExpense->transaction_type = $request->transaction_type; // transaction type
   
           $newPropertyExpense->category = $request->category; // is it rent or a penalty
   
           $newPropertyExpense->amount_involved = $request->amount_involved; // amount received from tenant
   
           $newPropertyExpense->date_incurred = $request->date_incurred; // transaction date
   
           $newPropertyExpense->save(); // persist the record into the database
   
           return redirect()->route('transactions.index')
               ->with('success','property Expense added successfully');
       }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
