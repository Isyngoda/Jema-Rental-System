<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Property;

use App\Unit;

class PropertyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      $properties = Property::latest()->paginate(6);
       return view('property.index',compact('properties'))
       ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('property.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      // validate the incoming request before storing the data
      //dump($request->all());
         request()->validate([
             'propName'  => 'required',
             'plotNo'    => 'required',
             'blockNo'    => 'required',
             'propType'  => 'required',
             'street'    => 'required',
             'region'    => 'required',
             'unit_no'   => 'required',
             'unit_type' => 'required',
             'unit_rent' => 'required',
           ]);
       $newlyCreatedProperty = new Property(); // create a new instance of class property

       $newlyCreatedProperty->propName = $request->propName; // assign the property's name

       $newlyCreatedProperty->propType = $request->propType; // assign street

       $newlyCreatedProperty->plotNo = $request->plotNo; // assign plot no

       $newlyCreatedProperty->blockNo = $request->blockNo; // assign block no

       $newlyCreatedProperty->street = $request->street; // assign street

       $newlyCreatedProperty->region = $request->region; // assign region

       $newlyCreatedProperty->save(); // persist the newly instantiated object in the database


       // count the number of array elements in the given array

       $numberOfElementsInArray = count($request -> unit_no);
       // loop through all the elements in the array

       for($i = 0; $i<$numberOfElementsInArray-1; $i++)
       {
             // create and instante a new unit object

             $newlyCreatedUnit = new Unit(); // create the object

             $newlyCreatedUnit->propertyId = $newlyCreatedProperty->id; // assign its property_id value

             $newlyCreatedUnit->unit_no = $request->unit_no[$i]; // assign its unit_no value

             $newlyCreatedUnit->unit_type = $request->unit_type[$i]; // assign its unit_type value

             $newlyCreatedUnit->unit_rent = $request->unit_rent[$i]; // assign its unit_rent value

             $newlyCreatedUnit->save(); // persist the newly created unit object to the database

       }



       $properties = Property::all();
       return view('property.index', compact('properties'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
      $property = Property::find($id);
      return view('property.view',compact('property'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $property = Property::find($id);
        return view('property.edit',compact('property'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        request()->validate([
          'propName'  => 'required',
          'plotNo'    => 'required',
          'blokNo'    => 'required',
          'street'    => 'required',
          'region'    => 'required',
          'rent'      => 'required',
        ]);
        Property::find($id)->update($request->all());
        return redirect()->route('properties.index')
                        ->with('success','Property updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Property::find($id)->delete();
        return redirect()->route('properties.index')
                        ->with('success','Property deleted successfully');
    }
}
