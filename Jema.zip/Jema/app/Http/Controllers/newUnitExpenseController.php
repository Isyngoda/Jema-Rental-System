<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\newModelTenant; // import the required model class

use App\propertyForRent; // import the required model class

use DB; // import the query builder

use App\propertyUnit; // import the required model class

use App\unitExpense; // import the required model class

class newUnitExpenseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // get the list of tenants for the drop downs

        $tenant = newModelTenant::select('id', DB::raw("concat(first_name, ' ' , last_name) as full_name"))->pluck('full_name' , 'id');
        
        $property = propertyForRent::pluck('property_name' , 'id'); // get the property's for the drop downs

        $unit = propertyUnit::pluck('unit_type', 'id');  // get the units for the drop downs
        
        return view('transactions.expense.unit.create', compact('tenant', 'property', 'unit')); // return the required view
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
         'newModelTenant_id' => 'required',
         'unit_id' => 'required',
         'property_id' => 'required',
         'date_incurred' => 'required',
         'category' => 'required',
         'amount_involved' => 'required',
         'transaction_type' => 'required',
        ]);

        $newUnitExpense = new unitExpense(); // create a new object
        
        // fetch a required tenant record
        
        $tenant = newModelTenant::select(DB::raw("concat(first_name, ' ' , last_name) as full_name"))->where('id', $request->newModelTenant_id)->first();
                
        // fetch the required record using id

        $unit = propertyUnit::select('unit_type')->where('id', $request->unit_id)->first();

        // fetch the required property using id

        $property = propertyForRent::select('property_name')->where('id', $request->property_id)->first();

        // now lets assign the values into proper columns

        $newUnitExpense->unit = $unit['unit_type'];  // the unit type

        $newUnitExpense->tenant = $tenant['full_name']; // tenant

        $newUnitExpense->property = $property['property_name']; // property name

        $newUnitExpense->transaction_type = $request->transaction_type; // transaction type

        $newUnitExpense->category = $request->category; // is it rent or a penalty

        $newUnitExpense->amount_involved = $request->amount_involved; // amount received from tenant

        $newUnitExpense->date_incurred = $request->date_incurred; // transaction date

        $newUnitExpense->save(); // persist the record into the database

        return redirect()->route('transactions.index')
            ->with('success','unit expense added successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
