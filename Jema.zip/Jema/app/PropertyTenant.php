<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Database\Eloquent\Relations\Pivot;

use App\Property;

use App\Tenant;

class PropertyTenant extends Pivot
{
  public function properties()
  {
  return $this->belongsToMany('App\Property')->withPivot('propertyId');
  }

  public function tenants()
  {
    return $this->belongsToMany('App\Tenant')->withPivot('tenantId');
  }
}
