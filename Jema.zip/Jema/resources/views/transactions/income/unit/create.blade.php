@extends('layouts.header')

@section('breadcrumb')

  <a href="{{route('transactions.index')}}">Accounting</a>

@stop

@section('breadcrumb2')

  Add Income

@stop

@section('content')
<div class="content">
    <div class="container-fluid">
        <div class="row">
        <div class="col-md-2">
                    <a class="btn btn-success" href="{{route('unitMonthlyTransactions.create')}}">+ Add Unit Income</a>
                </div>
                                            
                <div class="col-md-2">
                    <a class="btn btn-success" href="{{route('propertyMonthlyTransactions.create')}}">+ Add Property Income</a>
                </div>
                <br/><br /><hr/>
            <div class="col-md-12">
                 
                <div class="card">
                
                    <div class="header">
                        <h4 class="title">Add Unit Income</h4>
                    </div>
                    <div class="content all-icons">
                        {!! Form::open(array('route' => 'unitMonthlyTransactions.store','method'=>'POST')) !!}
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label value="tenantId">Payer / Payee</label>
                                    {!!Form::select('newModelTenant_id', $tenant, null, array('class'=>'form-control', 'placeholder'=>'Select Tenant'))!!}
                                </div>
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Unit</label>
                                    {!!Form::select('unit_id', $unit, null, array('class'=>'form-control', 'placeholder'=>'Select Unit'))!!}
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label value="propertyId">Property</label>
                                    {!!Form::select('property_id', $property, null, array('class'=>'form-control', 'placeholder'=>'Select Property'))!!}
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label value="propertyId">Transaction type</label>
                                    {!!Form::select('transaction_type',['prepaid' => 'PrePaid', 'cash' => 'Cash', 'credit' => 'Credit'], null, array('class'=>'form-control', 'placeholder'=>'Select transaction type'))!!}
                                </div>
                            </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="content table-responsive table-full-width">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                            <th>Start</th>
                                            <th>End Date</th>
                                            <th>Category</th>
                                            <th>Amount</th>
                                            <th>Paid Date</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    {!! Form::date('from', null, array('placeholder' => 'Start Date','class' => 'form-control')) !!}
                                                </td>
                                                <td>
                                                    {!! Form::date('to', null, array('placeholder' => 'End Date','class' => 'form-control')) !!}
                                                </td>
                                                <td>
                                                    {!!Form::select('category', ['Rent' => 'Rent', 'Penalty' => 'Penalty'], null, array('class'=>'form-control', 'placeholder'=>'Select Category'))!!}
                                                </td>
                                                <td>
                                                    {!! Form::text('amount_received',  null, array('placeholder' => 'Amount','class' => 'form-control')) !!}
                                                </td>
                                                <td>
                                                    {!! Form::date('date_of_transaction', null, array('placeholder' => 'Pay Date','class' => 'form-control')) !!}
                                                </td>
                                                <td>
                                                </td>

                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <input type="submit" class="btn btn-warning btn-fill pull-right"></button>
                        <div class="clearfix"></div>
                        {!! Form::close()!!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
