@extends('layouts.header')

@section('breadcrumb')

  Operating Report

@stop

@section('content')

  <div class="content">
      <div class="container-fluid">
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="content">
                          <form>
                              <div class="row">
                                  <div class="col-md-10">
                                      <div class="form-group">
                                          <label>Sort by Property</label>
                                          <select class="form-control">
                                              <option>all properties</option>
                                              <option>Seedfarm</option>
                                              <option>Msamala</option>
                                          </select>
                                      </div>
                                  </div>
                                  <div class="col-md-2">
                                      <div class="form-group">
                                          <label>Download PDF & Excel</label>
                                          <input type="submit" class="btn btn-success pull-right" value="Download">
                                      </div>
                                  </div>
                              </div>
                          </form>
                      </div>
                  </div>
              </div>
          </div>
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="content">
                          <div class="row">
                              <div class="col-md-9">
                                  <div class="" style="padding: 20px 10px;">
                                      <h3>OPERATING STATEMENT</h3>
                                  </div>
                              </div>
                              <div class="col-md-3">
                                  <div class="">
                                      <p style="text-align: right; padding: 20px 10px;">
                                          Jema <br>
                                          +255789828005 <br>
                                          evansanselm@gmail.com <br>
                                          01/01/2017 - 13/10/2017
                                      </p>
                                  </div>
                              </div>
                          </div>
                          <div class="row">
                              <div class="col-md-12">
                                  <div class="content table-responsive table-full-width">
                                      <table class="table">
                                          <thead>
                                              <tr>
                                                  <td colspan="6">
                                                      <p>
                                                          <small>PROPERTY</small><br>
                                                          SEEDFARM<br>
                                                          <small>seedfarm, Songea, Ruvuma Region, 105716, TZ</small>
                                                      </p>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <th width="35%">Account</th>
                                                  <th width="35%">Amount</th>
                                                  <th width="30%">Type</th>
                                              </tr>

                                          </thead>
                                          <tbody>
                                              <tr>
                                                  <td>Rent</td>
                                                  <td>Tsh 150,000</td>
                                                  <td>Income</td>
                                              </tr>
                                              <tr>
                                                  <td colspan="2"></td>
                                                  <td align="right" colspan="2" style="background: #333; color: #fff;">
                                                      <div>
                                                          <small>Income Total</small>
                                                          <p>Tsh 150,000</p>
                                                      </div>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td>Plumbing</td>
                                                  <td>Tsh 50,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td>Painting</td>
                                                  <td>Tsh 20,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td>Electical Maintenance</td>
                                                  <td>Tsh 50,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td colspan="2"></td>
                                                  <td align="right" colspan="2" style="background: #333; color: #fff;">
                                                      <div>
                                                          <small>Expense Total</small>
                                                          <p>Tsh 120,000</p>
                                                      </div>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td align="right" colspan="3" style="background: #333; color: #fff;">
                                                      <div>
                                                          <small>Net Cash-flow</small>
                                                          <p>Tsh 30,000</p>
                                                      </div>
                                                  </td>
                                              </tr>
                                          </tbody>
                                      </table>
                                  </div>

                                  <div class="content table-responsive table-full-width">
                                      <table class="table">
                                          <thead>
                                              <tr>
                                                  <td colspan="6">
                                                      <p>
                                                          <small>PROPERTY</small><br>
                                                          MSAMALA<br>
                                                          <small>seedfarm, Songea, Ruvuma Region, 105716, TZ</small>
                                                      </p>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <th width="35%">Account</th>
                                                  <th width="35%">Amount</th>
                                                  <th width="30%">Type</th>
                                              </tr>

                                          </thead>
                                          <tbody>
                                              <tr>
                                                  <td>Rent</td>
                                                  <td>Tsh 150,000</td>
                                                  <td>Income</td>
                                              </tr>
                                              <tr>
                                                  <td colspan="2"></td>
                                                  <td align="right" colspan="2" style="background: #333; color: #fff;">
                                                      <div>
                                                          <small>Income Total</small>
                                                          <p>Tsh 150,000</p>
                                                      </div>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td>Plumbing</td>
                                                  <td>Tsh 50,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td>Painting</td>
                                                  <td>Tsh 20,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td>Electical Maintenance</td>
                                                  <td>Tsh 50,000</td>
                                                  <td>Expense</td>
                                              </tr>
                                              <tr>
                                                  <td colspan="2"></td>
                                                  <td align="right" colspan="2" style="background: #333; color: #fff;">
                                                      <div>
                                                          <small>Expense Total</small>
                                                          <p>Tsh 120,000</p>
                                                      </div>
                                                  </td>
                                              </tr>
                                              <tr>
                                                  <td align="right" colspan="3" style="background: #333; color: #fff;">
                                                      <div>
                                                          <small>Net Cash-flow</small>
                                                          <p>Tsh 30,000</p>
                                                      </div>
                                                  </td>
                                              </tr>
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

@endsection
