@extends('layouts.header')

@section('breadcrumb')
  
  <a href="{{route('properties.index')}}">Properties</a>

@stop

@section('breadcrumb2')
  
  Edit Property

@stop

@section('content')

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Edit Property</h4>
                    </div>
                    <div class="content">
                       
                        {!! Form::model($property,['method' => 'PATCH','route' => ['properties.update', $property->id], 'files' => 'true']) !!}
                        <div class="row">
                            <div class="col-md-12">
                                <label><b>General Information</b></label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Property Name</label>
                                    {!! Form::text('property_name', null, array('placeholder' => 'Property Name','class' => 'form-control')) !!}
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Plot No:</label>
                                    {!! Form::text('plot_no', null, array('placeholder' => 'Plot No','class' => 'form-control')) !!}
                                </div>
                                
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Block No:</label>
                                    {!! Form::text('block_no', null, array('placeholder' => 'Block No','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Street Address</label>
                                    {!! Form::text('street', null, array('placeholder' => 'Street','class' => 'form-control')) !!}
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Region / City</label>
                                    {!! Form::text('region', null, array('placeholder' => 'Region','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>
                        
                        <hr>

                        <div class="row">
                            <div class="col-md-12">
                                <label><b>Property Type</b></label>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-12">
                                {!!Form::select('property_type', ['Single-Unit' => 'Single-Unit', 'Multi-Unit' => 'Multi-    Unit'],
                                null, array('class'=>'form-control', 'placeholder'=>'Select Category'))!!}
                            </div>
                        </div>
                        
                        <hr>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Market Rent</label>
                                    {!! Form::text('fixed_monthly_rent', null, array('placeholder' => 'Market Rent ex 10,000','class' => 'form-control')) !!}
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Property Image</label>
                                    {!! Form::file('profile', null, array('placeholder' => 'Image','class' => 'form-control')) !!}
                                </div>
                            </div>
                        </div>   

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    {!! Form::hidden('status', '0') !!}
                                </div>
                            </div>
                            <div class="col-md-4"></div>
                        </div>
                        <button type="submit" class="btn btn-default btn-fill pull-left">Back</button>
                        <button type="submit" class="btn btn-info btn-fill pull-right">Save</button>
                        <div class="clearfix"></div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-user">
                <a href="#">
                                <img src="{{url('propertyImages',$property->profile)}}" alt=""/>    
                            </a>
                    <div class="content">
                        <div class="author">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection