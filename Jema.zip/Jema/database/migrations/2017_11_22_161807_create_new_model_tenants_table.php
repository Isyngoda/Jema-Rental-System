<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNewModelTenantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('new_model_tenants', function (Blueprint $table) {
            $table->increments('id'); // the primary key of the tenant
            $table->string('first_name'); // the first name of the tenant
            $table->string('middle_name')->nullable();
            $table->string('last_name'); // the last name of the tenant
            $table->date('date_of_birth'); // the tenant's date of birth
            $table->char('sex'); // the tenant's sex or gender
            $table->string('email')->nullable(); // the tenant's email address
            $table->string('phone'); // tenants phone number
            $table->timestamps(); // the created_at and updated_at timestamps
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('new_model_tenants');
    }
}
