<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUnitMonthlyTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('unit_monthly_transactions', function (Blueprint $table) {
            $table->increments('id'); // the primary key of the transaction
            $table->string('unit'); // the unit to which this transaction is attached
            $table->string('property'); // the property in which a unit exist
            $table->string('transaction_type'); // the type of the transaction           
            $table->date('date_of_transaction'); // the date the transaction took place
            $table->string('category'); // is it rent or payment
            $table->date('from');  // the date from which the transaction is valid
            $table->date('to'); // the date to which the transaction is valid
            $table->decimal('amount_received', 7, 2); // thhe amount received by the business
            $table->string('newModelTenant'); // paid by
            $table->timestamps(); // the created_at and updated_at timestamps
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('unit_monthly_transactions');
    }
}
