<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLeasePreferencesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lease_preferences', function (Blueprint $table) {
            $table->increments('id'); // the primary key of the prefernce
            $table->string('description'); // a brief description of the preference
            $table->decimal('apprximate_cost', 7, 2); // an approximate cost to realize the preference
            $table->timestamps(); // a created_at and updated_at timestamps
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lease_preferences');
    }
}
