

<?php $__env->startSection('breadcrumb'); ?>
  
  <a href="<?php echo e(route('tenants.index')); ?>">Tenants</a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb2'); ?>
  
  <?php echo e($tenant -> first_name); ?> <?php echo e($tenant -> last_name); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content">
           <div class="container-fluid">
               <div class="row">
                   <div class="col-md-8">
                       <div class="card">
                           <div class="header">
                               <h4 class="title"><?php echo e($tenant -> first_name); ?> <?php echo e($tenant -> midlle_name); ?> <?php echo e($tenant -> last_name); ?></h4>
                               <label>Tenant profile</label>
                           </div>
                           <div class="content all-icons">

                               <div class="row">
                                   <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                       <div class="font-icon-detail">
                                           <p>Total Deposits</p>
                                           <h3>Tsh 1,000,000</h3>
                                       </div>
                                   </div>
                                   <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                       <div class="font-icon-detail">
                                           <p>Total Overdue</p>
                                           <h3>Tsh 100,000</h3>
                                       </div>
                                   </div>
                                   <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                       <div class="font-icon-detail">
                                           <p>Total Credits</p>
                                           <h3>Tsh 50,000</h3>
                                       </div>
                                   </div>
                               </div>

                               <hr>

                               <div class="row">
                                   <div class="col-md-12">
                                       <label>General Information</label><br />
                                   </div>
                               </div>

                               <div class="row">
                                   <div class="col-md-4">
                                       <div class="form-group">
                                           <label>First Name</label>
                                           <p><?php echo e($tenant -> first_name); ?></p>
                                       </div>
                                   </div>
                                   <div class="col-md-4">
                                       <div class="form-group">
                                           <label>Middle Name</label>
                                           <p><?php echo e($tenant -> middle_name); ?></p>
                                       </div>
                                   </div>
                                   <div class="col-md-4">
                                       <div class="form-group">
                                           <label>Last Name</label>
                                           <p><?php echo e($tenant -> last_name); ?></p>
                                       </div>
                                   </div>
                               </div>

                               <div class="row">
                                   <div class="col-md-4">
                                       <div class="form-group">
                                           <label>Date of Birth</label>
                                           <p><?php echo e($tenant -> date_of_birth); ?></p>
                                       </div>
                                   </div>
                                   <div class="col-md-4">
                                       <div class="form-group">
                                           <label>Age</label>
                                           <p><?php echo e($tenant -> age); ?> years</p>
                                       </div>
                                   </div>
                                   <div class="col-md-4">
                                       <div class="form-group">
                                           <label>Gender</label>
                                           <p><?php echo e($tenant -> sex); ?> </p>
                                       </div>
                                   </div>
                               </div>

                               <div class="row">
                                   <div class="col-md-6">
                                       <div class="form-group">
                                           <label for="exampleInputEmail1">Email address</label>
                                           <p><?php echo e($tenant -> email); ?></p>
                                       </div>
                                   </div>
                                   <div class="col-md-6">
                                       <div class="form-group">
                                           <label>Phone</label>
                                           <p><?php echo e($tenant -> phone); ?></p>
                                       </div>
                                   </div>
                               </div>

                               <hr>

                               <div class="row">
                                   <div class="col-md-12">
                                       <label><b>Assigned Property</b></label>
                                   </div>
                               </div>

                               <div class="row">
                                   <div class="col-md-6">
                                       <div class="form-group">
                                           <label>Property Name</label>
                                           <p>Seedfarm Villa</p>
                                       </div>
                                   </div>
                                   <div class="col-md-3">
                                       <div class="form-group">
                                           <label>Unit</label>
                                           <p>1</p>
                                       </div>
                                   </div>
                                   <div class="col-md-3">
                                       <div class="form-group">
                                           <label>Duration</label>
                                           <p>3 Months</p>
                                       </div>
                                   </div>
                               </div>

                               <div class="row">
                                   <div class="col-md-6">
                                       <div class="form-group">
                                           <label>Start Date</label>
                                           <p>04-10-2017</p>
                                       </div>
                                   </div>
                                   <div class="col-md-6">
                                       <div class="form-group">
                                           <label>End Date</label>
                                           <p>04-10-2018</p>
                                       </div>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>
                   <div class="col-md-4">
                       <div class="card card-user">
                           <div class="image">
                               <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                           </div>
                           <div class="content">
                               <div class="author">
                                   <a href="<?php echo e(route('tenants.edit', $tenant->id)); ?>"/>
                                       <img class="avatar border-gray" src="../assets/img/property.jpg" alt="..."/>

                                       <input type="button" class="form-control" value="Edit Tenant">
                                   </a>
                               </div>
                           </div>
                       </div>
                   </div>

               </div>
           </div>
       </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>