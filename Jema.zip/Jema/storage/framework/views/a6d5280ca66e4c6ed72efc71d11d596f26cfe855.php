

<?php $__env->startSection('breadcrumb'); ?>

  Reports

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

  <div class="content">
      <div class="container-fluid">
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Reports</h4>
                          <p class="category">Sub heading goes here</p>
                      </div>
                      <div class="content" style="margin-top: 20px;">
                          <div class="row">
                              <div class="col-md-5">
                                  <p>FINANCIAL REPORT <br> <a href="<?php echo e(route('expenseReport')); ?>">EXPENSE REPORT</a></p>
                              </div>
                              <div class="col-md-7">
                                  <p>
                                      This report provides the expenses based on the property or a specific unit. It is available for accrual type accounting only. The report shows all paid expense invoices for all properties and units excluding liabilities (deposit, prepaid rent, pet deposit, etc.). This report can be searched based on owner.
                                  </p>
                              </div>
                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-md-5">
                                  <p>RENTAL REPORT <br> <a href="<?php echo e(route('leaseStatement')); ?>">LEASE STATEMENT</a></p>
                              </div>
                              <div class="col-md-7">
                                  <p>
                                      This report shows all leases based on property and searchable by owner. The report includes information on the lease start date, ending date, tenant’s name, unit and if a balance is owed.
                                  </p>
                              </div>
                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-md-5">
                                  <p>FINANCIAL REPORT <br> <a href="<?php echo e(route('monthlyProperty')); ?>">MONTHLY PROPERTY REPORT</a></p>
                              </div>
                              <div class="col-md-7">
                                  <p>
                                      This report shows the property accounting based on each unit. The income and expenses including payment to owner and management fees. This report is designed to be for a property manager in order to deliver to an owner.
                                  </p>
                              </div>
                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-md-5">
                                  <p>FINANCIAL REPORT <br> <a href="<?php echo e(route('operatingReport')); ?>">OPERATING STATEMENT</a></p>
                              </div>
                              <div class="col-md-7">
                                  <p>
                                      This report shows the invoices of which have been marked “paid” for both income and expenses. The report includes records for all properties and units excluding liabilities categories (deposit, prepaid rent, pet deposit, etc.). The purpose of this report is to monitor cash-flow coming in and out of the rental property.
                                  </p>
                              </div>
                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-md-5">
                                  <p>RENTAL REPORT <br> <a href="#">RENT ROLL</a></p>
                              </div>
                              <div class="col-md-7">
                                  <p>
                                      This report shows all tenants that have an active lease in each property. The report includes the tenant's name, deposits held, market rent and the balance owed. This report can be searched by property owner or property.
                                  </p>
                              </div>
                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-md-5">
                                  <p>FINANCIAL REPORT <br> <a href="#">TAX PREPARATION REPORT</a></p>
                              </div>
                              <div class="col-md-7">
                                  <p>
                                      Report that shows all income and expenses for a specific period of time. This report is designed to help a landlord file their taxes. The report will include all income as well as expenses, management fees paid, depreciation and interest expense over the set time period. Deposits, Prepaid rent and other liabilities will not be included.
                                  </p>
                              </div>
                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-md-5">
                                  <p>RENTAL REPORT <br> <a href="#">TENANT STATEMENT</a></p>
                              </div>
                              <div class="col-md-7">
                                  <p>
                                      This report shows a tenant’s accounting based on when it was due. The report includes deposits, prepaid rent and other deposits. It will also include all invoices outstanding to date. Any blank or empty amounts in the Paid column are amounts that are outstanding or have not been entered.
                                  </p>
                              </div>
                          </div>
                          <hr>
                          <div class="row">
                              <div class="col-md-5">
                                  <p>RENTAL REPORT <br> <a href="#">CONTACTS REPORT</a></p>
                              </div>
                              <div class="col-md-7">
                                  <p>
                                      This report shows tenant’s contact information, owner's contact information, vendor's contact information, service pro's contact information.
                                  </p>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>