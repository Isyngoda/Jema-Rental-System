<?php $__env->startSection('content'); ?>
                <div class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="card">
                                    <div class="header">
                                        <h4 class="title"><?php echo e($property -> propName); ?></h4>
                                    </div>
                                    <div class="content">
                                        <h5 class="title">Financials</h5>

                                        <div id="chartHours" class="ct-chart"></div>

                                        <div class="footer">
                                            <div class="legend">
                                                <i class="fa fa-circle text-info"></i> Income
                                                <i class="fa fa-circle text-danger"></i> Expenses
                                            </div>
                                        </div>

                                        <hr>

                                        <h5 class="title">Units</h5>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="content table-responsive table-full-width">
                                                    <table class="table table-hover table-striped">
                                                        <thead>
                                                            <th>Tenant Name</th>
                                                            <th>Property Type</th>
                                                            <th>Unit No:</th>
                                                            <th>Action</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>Dakota Rice</td>
                                                                <td><?php echo e($property -> propType); ?></td>
                                                                <td>1</td>
                                                                <td><a href="" class="btn btn-primary">View Unit</a></td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card card-user">
                                    <div class="image">
                                        <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt="..."/>
                                    </div>
                                    <div class="content">
                                        <div class="author">
                                             <a href="#">
                                                 <img class="avatar border-gray" src="../assets/img/property.jpg" alt="..."/>
                                                 <h4 class="title"><?php echo e($property -> propName); ?><br />
                                                     <small><?php echo e($property -> street); ?></small>
                                                 </h4>
                                            </a>
                                            <p class="description text-center">
                                                 <?php echo e($property -> region); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>