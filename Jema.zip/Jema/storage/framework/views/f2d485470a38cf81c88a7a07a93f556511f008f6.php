

<?php $__env->startSection('breadcrumb'); ?>
  
  <a href="<?php echo e(route('properties.index')); ?>">Properties</a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb2'); ?>
  
  <?php echo e($property -> propName); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="header">
                        <h4 class="title"><?php echo e($property -> property_name); ?></h4>
                    </div>
                    <div class="content">
                        <h5 class="title">Summary of Financials</h5>
                        
                        <div id="chartHours" class="ct-chart"></div>
                        
                        <div class="footer">
                            <div class="legend">
                                <i class="fa fa-circle text-success"></i> Income
                                <i class="fa fa-circle text-danger"></i> Expenses
                            </div>
                        </div>
                        
                        <hr>

                        <h5 class="title">Units</h5>
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="content table-responsive table-full-width">
                               
                                    <table class="table table-hover table-striped">
                                    <?php if(!empty($units)): ?>
                                        <thead>
                                            <th>Unit No:</th>
                                            <th>Unit Type</th>
                                            <th>Fixed Monthly Rent</th>
                                            <th>Occupied</th>
                                            <th>Tenant</th>
                                            <th>Action</th>
                                        </thead>
                                        <tbody>
                                         <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($unit->unit_no); ?></td>
                                                <td><?php echo e($unit->unit_type); ?></td>
                                                <td><?php echo e($unit->fixed_monthly_rent); ?></td>
                                                <?php if(!empty($unit->occupied)): ?>
                                                  <td><?php echo e($unit->occupied); ?></td>
                                                <?php else: ?>
                                                  <td>No</td>
                                                <?php endif; ?>
                                                <td>Default</td>
                                                <td><a href="" class="btn btn-primary">View Unit</a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <?php elseif(empty($units)): ?>
                                           <p>This property has no units</p>
                                         <?php endif; ?>
                                    </table>
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-user">
                    <div class="image">
                        <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt=""/>
                    </div>
                    <div class="content">
                        <div class="author">
                            <a href="<?php echo e(route('properties.show', $property->id)); ?>" title="View Property">
                                <img class="avatar border-gray" src="<?php echo e(url('propertyImages', $property->profile)); ?>" alt=""/>
                                                    
                                <h4 class="title"><?php echo e($property -> propName); ?><br />
                                    <small>Plot No: <?php echo e($property -> plot_no); ?>, Block No: <?php echo e($property ->block_no); ?></small>
                                    <br /><small>Street: <?php echo e($property -> street); ?> <br /> Region: <?php echo e($property -> region); ?></small>
                                </h4>
                            </a>
                        
                            <p class="description text-center">
                                
                            </p>
                            <a class="btn btn-primary" href="<?php echo e(route('properties.edit',$property->id)); ?>">Edit</a>
                            <?php echo Form::open(['method' => 'DELETE','route' => ['properties.destroy', $property->id],'style'=>'display:inline']); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>