

<?php $__env->startSection('breadcrumb'); ?>

  Tenants

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="header">
                        <div class="col-md-10">
                            <div class="row">
                                <h4 class="title">All Tenants</h4>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <a class="btn btn-primary" href="<?php echo e(route('tenants.create')); ?>">+ Add new tenant</a>
                        </div>
                    </div>
                    <div class="content" style="margin-top: 40px;">
                        <div class="row">
                            <div class="content table-responsive table-full-width">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email:</th>
                                        <th>Phone</th>
                                        <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $tenants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tenant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($tenant -> first_name); ?></td>
                                            <td><?php echo e($tenant -> last_name); ?></td>
                                            <td><?php echo e($tenant -> email); ?></td>
                                            <td><?php echo e($tenant -> phone); ?></td>
                                
                                            <td width="20%">
                                                <a href="<?php echo e(route('tenants.show', $tenant -> id)); ?>" class="btn btn-info" title="View More Information"><i class="fa fa-eye"></i></a>
                                                <a href="<?php echo e(route('tenants.edit',$tenant->id)); ?>" class="btn btn-warning" title="Edit tenant information"><i class="fa fa-edit"></i></a>
                                                <?php echo Form::open(['method' => 'DELETE','route' => ['tenants.destroy', $tenant->id],'style'=>'display:inline']); ?>

                                                <?php echo Form::submit('X',['class' => 'btn btn-danger']); ?>

                                                <?php echo Form::close(); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>