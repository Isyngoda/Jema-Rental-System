<?php $__env->startSection('breadcrumb'); ?>
  
  <a href="<?php echo e(route('transactions.index')); ?>">Accounting</a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="col-md-12">
                        <div class="header">
                            <div class="col-md-8">
                                <div class="row">
                                    <h4 class="title">All Transactions</h4>
                                    <p class="category">Sub heading goes here</p>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <a class="btn btn-primary" href="<?php echo e(route('incomes.create')); ?>">+ Add new Income</a>
                            </div>
                            <div class="col-md-2">
                                <a class="btn btn-danger" href="<?php echo e(route('expenses.create')); ?>">+ Add new Expense</a>
                            </div>
                        </div>
                    </div>
                    <div class="content all-icons">

                        <div class="row">
                            <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                <div class="font-icon-detail">
                                    <p>Total Transactions</p>
                                    <h3>Tsh <?php echo e($transTotal); ?></h3>
                                </div>
                            </div>
                            <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                <div class="font-icon-detail">
                                    <p>Total Income</p>
                                    <h3>Tsh <?php echo e($incomeTotal); ?></h3>
                                </div>
                            </div>
                            <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                <div class="font-icon-detail">
                                    <p>Total Expense</p>
                                    <h3>Tsh <?php echo e($expenseTotal); ?></h3>
                                </div>
                            </div>
                        </div>

                          <hr>

                          <div class="row">
                              <div class="col-md-12">
                                  <div class="content table-responsive table-full-width">
                                      <table class="table table-hover">
                                          <thead>
                                              <th>Status</th>
                                              <th>Pay Date</th>
                                              <th>Person</th>
                                              <th>Property</th>
                                              <th>Total/Paid</th>
                                              <th>Action</th>
                                          </thead>
                                          <tbody>
                                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                              <tr>
                                                  <td><span class="label label-success">PAID</span></td>
                                                  <td><?php echo e($transaction -> payDate); ?></td>
                                                  <td><?php echo e($transaction -> category); ?><br> <small>From <a href=""><?php echo e($transaction -> Tenant -> fname); ?> <?php echo e($transaction -> Tenant -> sname); ?></a></small></td>
                                                  <td><small> <a href=""><?php echo e($transaction -> Property -> propName); ?>,</a> </small> <br> <small><?php echo e($transaction -> unit); ?></td>
                                                  <td><?php echo e($transaction -> amount); ?></td>
                                                  <td>
                                                      <a href="" class="btn btn-success">Details</a>
                                                  </td>
                                              </tr>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>