<?php $__env->startSection('content'); ?>

  <div class="content">
      <div class="container-fluid">
          <div class="row">
              <div class="col-md-12">
                  <div class="card">
                      <div class="header">
                          <h4 class="title">Transactions</h4>
                          <p class="category">Sub heading goes here</p>
                      </div>
                      <div class="content all-icons">

                          <div class="row">
                              <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <p>Pending Rent</p>
                                      <h3>Tsh 1,000,000</h3>
                                  </div>
                              </div>
                              <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <p>Received Rent</p>
                                      <h3>Tsh 100,000</h3>
                                  </div>
                              </div>
                              <div class="font-icon-list col-lg-4 col-md-4 col-sm-4 col-xs-6 col-xs-6">
                                  <div class="font-icon-detail">
                                      <p>Late Rent</p>
                                      <h3>Tsh 50,000</h3>
                                  </div>
                              </div>
                          </div>

                          <hr>

                          <div class="row">
                              <div class="col-md-12">
                                  <div class="content table-responsive table-full-width">
                                      <table class="table table-hover">
                                          <thead>
                                              <th>Status</th>
                                              <th>Due</th>
                                              <th>Person</th>
                                              <th>Property</th>
                                              <th>Total/Paid</th>
                                              <th>Action</th>
                                          </thead>
                                          <tbody>
                                            <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr>
                                                  <td><span class="label label-success">PAID</span></td>
                                                  <td><?php echo e($income -> endDate); ?></td>
                                                  <td><?php echo e($income -> category); ?><br> <small>From <a href=""><?php echo e($income -> Tenant -> fname); ?> <?php echo e($income -> Tenant -> sname); ?></a></small></td>
                                                  <td><small> <a href=""><?php echo e($income -> Property -> propName); ?>,</a> </small> <br> <small><?php echo e($income -> unit); ?></td>
                                                  <td><?php echo e($income -> amount); ?></td>
                                                  <td>
                                                      <a href="" class="btn btn-success">Details</a>
                                                  </td>
                                              </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>