<?php $__env->startSection('breadcrumb'); ?>
  
  <a href="<?php echo e(route('tenants.index')); ?>">Tenants</a>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb2'); ?>
  
  Edit Tenant

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="header">
                        <h4 class="title">Edit Tenant</h4>
                    </div>
                    <div class="content">
                        <?php echo Form::model($tenant, ['method' => 'PATCH','route' => ['tenants.update', $tenant->id]]); ?>

                        <div class="row">
                            <div class="col-md-12">
                                <label><b>General Information</b></label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>First Name</label>
                                    <?php echo Form::text('first_name', null, array('placeholder' => 'First Name','class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Middle Name</label>
                                    <?php echo Form::text('middle_name', null, array('placeholder' => 'Middle Name','class' =>   'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Last Name</label>
                                    <?php echo Form::text('last_name', null, array('placeholder' => 'Last Name','class' => 'form-control')); ?>

                                </div>
                            </div>
                        </div>
                    
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Date of Birth</label>
                                    <?php echo Form::date('date_of_birth', null, array('placeholder' => 'Date of Birth','class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Gender</label>
                                    <?php echo Form::select('sex', ['M' => 'Male', 'F' => 'Female'],
                                    null, array('class'=>'form-control', 'placeholder'=>'Select Gender')); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="exampleInputEmail1">Email address</label>
                                    <?php echo Form::email('email', null, array('placeholder' => 'Email','class' => 'form-control')); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone</label>
                                    <?php echo Form::text('phone', null, array('placeholder' => 'Phone No','class' => 'form-control')); ?>

                                </div>
                            </div>
                            
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-default btn-fill pull-left">Back</button>
                        <button type="submit" class="btn btn-info btn-fill pull-right">Save</button>
                        <div class="clearfix"></div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card card-user">
                    <div class="image">
                        <img src="https://ununsplash.imgix.net/photo-1431578500526-4d9613015464?fit=crop&fm=jpg&h=300&q=75&w=400" alt=""/>
                    </div>
                    <div class="content">
                        <div class="author">
                            <a href="">
                                <img class="avatar border-gray" src="<?php echo e(url('assets/img/property.jpg')); ?>" alt=""/>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>